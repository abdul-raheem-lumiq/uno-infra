import logging

from com.lumiq.framework.utils.DFUtils import DFUtils as F
from com.lumiq.framework.factory.ClassFactory import ClassFactory as cf
from com.lumiq.framework.utils.SecretUtils import SecretUtils as Sr
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging as logs
from pyspark.sql import Window
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql.types import StructType, StructField, StringType
import json
import requests



class JobUtils(object):
    @staticmethod
    def getUpdatedStates(spark, source_df, job_name, watermark_columns, source_schema, source_table_name):
        StateSchema = StructType([StructField('watermark_col_name', StringType()),
                                  StructField('watermark_col_val', StringType()),
                                  StructField('JobName', StringType()),
                                  StructField('Schema', StringType()),
                                  StructField('Table', StringType())])

        # watermark_column_list = [col(column.strip()) for column in watermark_columns.split(',')]
        # new_watermark_col_val = source_df.agg(max(date_format(coalesce(*watermark_column_list), "yyyy-MM-dd HH:mm:ss.SSS"))).collect()[0][0]

        watermark_column_formatted =[
            when(trim(col(column)) != '', col(column)).otherwise(None)
            for column in watermark_columns.split(',')]

        new_watermark_col_val = source_df.agg(
            max(date_format(coalesce(*watermark_column_formatted), "yyyy-MM-dd HH:mm:ss.SSS"))
        ).collect()[0][0]

        newState = [(f"coalesce({watermark_columns})", new_watermark_col_val, job_name, source_schema, source_table_name)]
        new_stateDF = spark.createDataFrame(data=newState, schema=StateSchema)
        return new_stateDF, new_watermark_col_val #state_df.drop('watermark_col_val').join(new_stateDF, ["watermark_col_name","Schema","Table","JobName"], "right")
    @staticmethod
    def getStateQuery(watermark_values_json):
        """
        Build state query
        :param watermark_values_json - Json with keys as the watermark column name and values as the timestamp to update the state with.

        :return State string i.e. "WHERE watermarkcolumnname > 'watermarkcolumnvalue'"
        """
        conditions = []
        for key, value in watermark_values_json.items():
            conditions.append(f"{key} > '{value}'")
        state_query = " WHERE " + " OR ".join(conditions)
        return state_query

    @staticmethod
    def getSourceTablesList(spark, path, source, schema=None, Group=None):
        """
        Get list of tables for an input Source (and Schema if it not None) mentioned in TableMaster.json
        :param spark - Spark Session
        :param path - TableMaster.json s3 Path
        :param source - Name of Source defined in TableMaster.json
        :param schema - Name of Schema for a Source defined in TableMaster.json [Default - None]
        :param Group - Name of Group, if tables are defined in a Group. [Default - None]

        :return list of tables
        """
        df = spark.read.option("multiLine", "true").json(path)
        if schema is None:
            if Group is None:
                df1 = df.filter((upper(col("Source")) == upper(lit(source))))
            else:
                df1 = df.filter((upper(col("Source")) == upper(lit(source))) &
                                (upper(col("Group")) == upper(lit(Group))))
        else:
            if Group is None:
                df1 = df.filter((upper(col("Source")) == upper(lit(source))) &
                                (upper(col("Schema")) == upper(lit(schema))))
            else:
                df1 = df.filter((upper(col("Source")) == upper(lit(source))) &
                                (upper(col("Schema")) == upper(lit(schema))) &
                                (upper(col("Group")) == upper(lit(Group))))
        dfCount = df1.count()
        if dfCount == 0:
            if schema is None:
                logs.warning(f"::::No tables found for the source {source}")
            else:
                logs.warning(f"::::No tables found for the source {source} and Schema {schema}.")
            details = {}
        else:
            details = [x.asDict() for x in df1.select(col("Source"), col("Table")).collect()]
        return details

    @staticmethod
    def getTableDetails(session, path, source, schema, table, mode='spark'):
        """
        Get table details for a source and schema mentioned in TableMaster.json
        :param session: Spark Session or Glue Context
        :param path - TableMaster.json s3 Path
        :param source - Name of Source defined in TableMaster.json
        :param schema - Name of Schema for a Source defined in TableMaster.json
        :param table - Name of Table
        :param mode - mode of session, possible value - spark or glue.[Default - spark]

        :return list of table details
        """
        if mode == 'spark':
            df = JobUtils.readDataFromS3(spark=session, path=path, dataFormat='json')
        elif mode == 'glue':
            df = JobUtils.readDataFromS3UsingGlue(glueContext=session, path=path, dataFormat='json')
        else:
            raise ValueError(f"Invalid read mode found {mode}")
        df1 = df.filter((upper(col("Source")) == upper(lit(source))) &
                        (upper(col("Schema")) == upper(lit(schema))) &
                        (upper(col("Table")) == upper(lit(table))))
        dfCount = df1.count()
        if dfCount == 0:
            logs.warning(f"::::Table '{schema}.{table}' details not found for the source {source}.")
            details = {}
        elif dfCount == 1:
            details = df1.collect()[0].asDict()
            for x in details:
                if ',' in details[x]:
                    details[x] = list(map(lambda y: y.strip(' ').lower(), details[x].split(",")))
                elif details[x].strip() == '':
                    details[x] = None
        else:
            msg = f"Duplicate record found for Source ' {source} ' and Table '{schema}.{table}' in TableMaster. "
            logs.error(msg)
            raise ValueError(msg)
        return details

    @staticmethod
    def readDataFromS3(spark, path, dataFormat):
        """
        Read data from S3 using Spark Session.
        :param spark: Spark Session
        :param path - input s3 data Path
        :param dataFormat - data format, Possible format parquet, json, csv, avro, orc.

        :return dataframe
        """
        try:
            if dataFormat.lower() == 'parquet':
                df = spark.read.parquet(path)
            elif dataFormat.lower() == 'json':
                df = spark.read.option("multiLine", "true").json(path)
            elif dataFormat.lower() == 'csv':
                df = spark.read.option("header", "true").csv(path)
            elif dataFormat.lower() == 'avro':
                df = spark.read.avro(path)
            elif dataFormat.lower() == 'orc':
                df = spark.read.orc(path)
            else:
                msg = f"No read method found for format {dataFormat}"
                logs.warning(msg)
                raise ValueError(msg)
            return df
        except Exception as e:
            logs.error(e)
            raise Exception(str(e))

    @staticmethod
    def readDataFromS3UsingGlue(glueContext, path, dataFormat, transformation_ctx=None):
        """
        Read data from S3 using Glue Context.
        :param glueContext: Glue Context
        :param path - input s3 data Path
        :param dataFormat - data format, Possible format parquet, json, csv, avro, orc.
        :param transformation_ctx - applicable when JobBookmark enable. Key to maintain the state of input path.

        :return dataframe
        """
        try:
            if transformation_ctx is None:
                ctx = F.EpochTime()
            else:
                ctx = transformation_ctx
            dataFormat = dataFormat.strip()
            if dataFormat.lower() == 'parquet':
                datasource = glueContext.create_dynamic_frame.from_options(connection_type="s3",
                                                                           connection_options={"path": path,
                                                                                               "recurse": True},
                                                                           format='parquet',
                                                                           transformation_ctx=ctx)
            elif dataFormat.lower() == 'json':
                datasource = glueContext.create_dynamic_frame.from_options(connection_type="s3",
                                                                           connection_options={"path": path,
                                                                                               "recurse": True},
                                                                           format='json',
                                                                           format_options={"multiline": True},
                                                                           transformation_ctx=ctx)
            elif dataFormat.lower() == 'csv':
                datasource = glueContext.create_dynamic_frame.from_options(connection_type="s3",
                                                                           connection_options={"path": path,
                                                                                               "recurse": True},
                                                                           format='csv',
                                                                           format_options={"withHeader": True},
                                                                           transformation_ctx=ctx)
            elif dataFormat.lower() == 'avro':
                datasource = glueContext.create_dynamic_frame.from_options(connection_type="s3",
                                                                           connection_options={"path": path,
                                                                                               "recurse": True},
                                                                           format='avro',
                                                                           transformation_ctx=ctx)
            elif dataFormat.lower() == 'orc':
                datasource = glueContext.create_dynamic_frame.from_options(connection_type="s3",
                                                                           connection_options={"path": path,
                                                                                               "recurse": True},
                                                                           format='orc',
                                                                           transformation_ctx=ctx)
            else:
                msg = f"No read method found for format {dataFormat}"
                logs.warning(msg)
                raise ValueError(msg)
            df = datasource.toDF()
            return df
        except Exception as e:
            logs.error(e)
            raise Exception(str(e))

    @staticmethod
    def AddMandateColumn(Config, df, Options):
        """
        Add Mandatory Columns Operation and watermark columns into dataframe if not available.
        :param Config: Config object of properties file.
        :param df - input dataframe where columns need to add.
        :param Options - Dict of operation and watermark column.

        :return dataframe
        """
        global_opColumn = Config.get('Datalake', 'datalake.operation.column')
        global_WColumn = Config.get('Datalake', 'datalake.watermark.column')
        if Options != '{}':
            opColumn = Options['OperationColumn'] if 'OperationColumn' in Options.key() else global_opColumn
            WColumn = Options['WatermarkColumn'] if 'WatermarkColumn' in Options.key() else global_WColumn
        else:
            opColumn = global_opColumn
            WColumn = global_WColumn

        if opColumn.strip() == '':
            df1 = df
        elif F.colExist(df, opColumn):
            df1 = df.withColumn(opColumn, when(col(opColumn).isNull(), lit("I")).otherwise(col(opColumn)))
        else:
            df1 = df.withColumn(opColumn, lit("I"))

        if WColumn.strip() == '':
            df2 = df1
        elif F.colExist(df1, "edl_created_at"):
            df2 = df1
        else:
            df2 = df1.withColumn("edl_created_at", rpad(concat((unix_timestamp(col(WColumn))),
                                                               coalesce(split(col(WColumn), "\\.")[1], lit("0"))),
                                                        16, '0').cast("long"))
        return df2

    @staticmethod
    def readTableFromS3UsingGlueOptions(glueContext, Config, Source, Schema,
                                        Table, dataLayer, dataFormat='parquet'):
        """
        Read DataLake table from s3 using Glue Context.
        :param glueContext: Glue Context.
        :param Config: Config object of properties file.
        :param Source: Table Source Name.
        :param Schema: Table Schema Name.
        :param Table:  Table Name.
        :param dataLayer:  DataLake layer Name such as Raw, Stage, Mirror etc.( as per defined in properties file).
        :param dataFormat - data format. Possible format parquet, json, csv, avro, orc. [default - Parquet]

        :return records count and dataframe
        """
        parentPath = Config.get(dataLayer.strip().title(), dataLayer.lower() + '.bucket.path')
        SrcDirProp = str(Source).upper() + '.' + dataLayer.lower() + str('.dir')
        SrcDir = Config.get(str(Source).upper(), SrcDirProp)
        Path = parentPath + str("/") + SrcDir + str("/") + str(Schema).upper() + str("/") + str(Table).upper() + str(
            "/*")
        FilePath = F.s3Path(Path)
        if Schema.strip() == '':
            SchemaTable = Table.strip()
        else:
            SchemaTable = Schema.strip() + str("_") + Table.strip()
        logs.info("[{}]::::Input Source Table {} Path is {}".format(dataLayer.title(), Table, FilePath))
        df = JobUtils.readDataFromS3UsingGlue(glueContext, FilePath, dataFormat, transformation_ctx=SchemaTable)
        Count = df.count()
        if Count != 0:
            JsonPath = Config.get('Environment', 's3.table.master.path')
            table_details = JobUtils.getTableDetails(glueContext, JsonPath, Source, Schema, Table, mode='glue')
            df1 = JobUtils.AddMandateColumn(Config, df, Options=table_details)
            return (Count, df1)
        return (Count, df)

    # Getting incremental data using Glue job bookmark by using Glue Catalog database Tables
    # Use this method when tables are created in Glue Catalog and table has Watermark Column.
    @staticmethod
    def readTableUsingGlueCatalog(glueContext, Config, Source, database, table, pushDownPredicate=None):
        """
        Read table from source database using Glue Context and glue Catalog.
        :param glueContext: Glue Context.
        :param Config: Config object of properties file.
        :param Source: Table Source Name.
        :param database: Table datbase name from Glue Catalog.
        :param table:  Name of catalog table.
        :param pushDownPredicate:  Filter push-down properties

        :return records count and dataframe
        """
        JsonPath = Config.get('Environment', 's3.table.master.path')
        table_details = JobUtils.getTableDetails(glueContext, JsonPath, Source, database, table, mode='glue')
        WColumn = str(table_details['WatermarkColumn'])
        ctx = database + '.' + table
        if WColumn.strip() != "":
            if pushDownPredicate is None:
                datasource0 = glueContext.create_dynamic_frame.from_catalog(database=database, table_name=table,
                                                                            transformation_ctx=ctx,
                                                                            additional_options={
                                                                                "jobBookmarkKeys": [WColumn],
                                                                                "jobBookmarksKeysSortOrder": "asc"})
            else:
                datasource0 = glueContext.create_dynamic_frame.from_catalog(database=database, table_name=table,
                                                                            transformation_ctx=ctx,
                                                                            push_down_predicate=pushDownPredicate,
                                                                            additional_options={
                                                                                "jobBookmarkKeys": [WColumn],
                                                                                "jobBookmarksKeysSortOrder": "asc"})
        else:
            if pushDownPredicate is None:
                datasource0 = glueContext.create_dynamic_frame.from_catalog(database=database, table_name=table)
            else:
                datasource0 = glueContext.create_dynamic_frame.from_catalog(database=database,
                                                                            table_name=table,
                                                                            push_down_predicate=pushDownPredicate)

        Count = datasource0.count()
        df = datasource0.toDF()
        return (Count, df)

    @staticmethod
    def readTableFromS3(spark, Config, Source, Schema, Table, dataLayer, Latest=True, dataFormat='parquet'):
        """
        Read table from  s3 DataLake using Spark.
        :param spark: spark Session.
        :param Config: Config object of properties file.
        :param Source: Table Source Name.
        :param Schema: Table Schema Name.
        :param Table:  Name of data lake table.
        :param dataLayer: DataLake layer Name such as Raw, Stage, Mirror etc.( as per defined in properties file).
        :param Latest: Flag to get latest snapshot of table. [default - True]
        :param dataFormat: data format. Possible format parquet, json, csv, avro, orc. [default - Parquet]

        :return dataframe
        """
        parentPath = Config.get(dataLayer.strip().title(), dataLayer.lower() + '.bucket.path')
        SrcDirProp = str(Source).upper() + '.' + dataLayer.lower() + str('.dir')
        SrcDir = Config.get(str(Source).upper(), SrcDirProp)
        Path = parentPath + str("/") + SrcDir + str("/") + str(Schema).upper() + str("/") + str(Table).upper() + str(
            "/*")
        FilePath = F.s3Path(Path)
        logs.info("[{}]::::Input Source Table {} Path is {}".format(dataLayer.title(), Table, FilePath))
        df = JobUtils.readDataFromS3(spark, FilePath, dataFormat)
        JsonPath = Config.get('Environment', 's3.table.master.path')
        table_details = JobUtils.getTableDetails(spark, JsonPath, Source, Schema, Table, mode='spark')
        df1 = JobUtils.AddMandateColumn(Config, df, Options=table_details)
        if Latest:
            df2 = JobUtils.getLatestData(spark, Config, df1, Source, Schema, Table)
        else:
            df2 = df1
        return df2

        # Reading Data from RDS using Spark Utility.
        # @Source - This is the name of the source defined in Connection Utils. For example RedShift
        #

    @staticmethod
    def readFromJDBC(spark: SparkSession, schema, tableName, secret_json, Options=None, region_name='ap-south-1'):
        """
        Read table data from source database using spark JDBC.
        :param spark: spark Session.
        :param schema: Table Schema Name.
        :param tableName:  Table Name.
        :param secret_name: AWS Secret manager name to get database credentials
        :param Options: Additional Spark JDBC Options[default - None]
        :param region_name:  AWS Secret manager region name. [default - 'ap-south-1']

        :return dataframe
        """
        try:
            secret, Properties = F.getProperties(secret_json)
            logs.info("Secret Retrieved Reading from JDBC")
        except Exception as e:
            logs.error(e, exc_info=True)
            return "Failed"
        table = str(schema) + str(".") + str(tableName)

        default_properties = {"url": secret['url'], "dbtable": table, "numPartitions": 10, "fetchsize": 10000}
        # logs.info("Secret json::::::::" + str(secret_json))
        # logs.info("Secret::::::::" + str(secret))
        # logs.info("Table ::::::::" + str(table))
        # logs.info("TableName ::::::::" + str(tableName))
        # logs.info("URL   ::::::::" + str(secret['url']))
        # logs.info("default prop::" + str(default_properties))
        if Options is not None:
            Prop = dict(list(default_properties.items()) + list(Properties.items()) + list(Options.items()))
            if 'ssl' in Prop:
                logs.info("::::SSL is Enabled for {}".format(secret['url']))
        else:
            Prop = dict(list(default_properties.items()) + list(Properties.items()))

        df = spark.read.format("jdbc").options(**Prop).load()
        logs.info("df schema ::::" + str(df.printSchema()))
        # logs.info("df        ::::" + str(df.show()))
        return df

    @staticmethod
    def readFromJDBCUsingQry(spark: SparkSession, Query, secret_json, Options=None, region_name='ap-south-1'):
        """
        Read table from source database using Spark
        :param spark: spark Session.
        :param Query: Custom Query.
        :param secret_name: AWS Secret manager name to get database credentials
        :param Options: Additional Spark JDBC Options[default - None]
        :param region_name:  AWS Secret manager region name. [default - 'ap-south-1']

        :return dataframe
        """
        try:
            #secret1 = Sr.getSecret(secret_name, region_name=region_name)
            secret, Properties = F.getProperties(secret_json)
        except Exception as e:
            logs.error(e, exc_info=True)
            return "Failed"
        default_properties = {"url": secret['url'], "query": Query, "numPartitions": 10, "fetchsize": 10000}
        if Options is not None:
            Prop = dict(list(default_properties.items()) + list(Properties.items()) + list(Options.items()))
            if 'ssl' in Prop:
                logs.info("::::SSL is Enabled for {}".format(secret['url']))
        else:
            Prop = dict(list(default_properties.items()) + list(Properties.items()))

        df = spark.read.format("jdbc").options(**Prop).load()
        return df

    # Method to read data from DynamoDB Table.
    @staticmethod
    def readFromDynamoDb(GlueContext, Table):
        """
        Read table from DynamoDB using Glue Context and glue Catalog.
        :param GlueContext: Glue  Context.
        :param Table:  AWS DynamoDb Table Name.

        :return dataframe
        """
        try:
            datasource = GlueContext.create_dynamic_frame.from_options(connection_type="dynamodb",
                                                                       connection_options={"tableName": Table}
                                                                       )
            Count = datasource.count()
            df = datasource.toDF()
            return ("Success", Count, df)
        except Exception as e:
            logs.error(e)
            return ("Failed -" + str(e), 0, "")

    # This method implement the logic to get latest snapshot from S3 Table. It uses edl_created_at column along with tables
    # watermark column if applicable and get first row number record. it will not give latest data if table does not
    # Primary Key.
    @staticmethod
    def getLatestData(spark, Config, df, Source, Schema, Table, Del=True):
        """
        Method to Get Latest DataLake Table Data by using Primary Key and watermark column
        :param spark: spark Session.
        :param Config: Config object of properties file.
        :param df: Input Spark Dataframe
        :param Source: Source of DataLake Table
        :param Schema: Schema of DataLake Table
        :param Table:  DataLake Table Name.
        :param Del:  Flag to return delete records or not. if True then it will remove deleted records (operation is
        delete) or else not.

        :return dataframe
        """
        JsonPath = Config.get('Environment', 's3.table.master.path')
        tableDetails = JobUtils.getTableDetails(spark, JsonPath, Source, Schema, Table, mode='spark')
        PrimaryColsList = tableDetails["PrimaryColumns"]
        PriCols = ",".join([str(x) for x in PrimaryColsList])

        if (PriCols.strip(' ') != ""):
            WColumn = tableDetails["WatermarkColumn"][0]
            if F.colExist(df, "edl_created_at"):
                if WColumn != "":
                    W = Window.partitionBy(PrimaryColsList).orderBy(col("edl_created_at").desc(), col(WColumn).desc())
                else:
                    W = Window.partitionBy(PrimaryColsList).orderBy(col("edl_created_at").desc())
            elif WColumn != "":
                W = Window.partitionBy(PrimaryColsList).orderBy(col(WColumn).desc())
            else:
                W = ""
                logs.error("::::Watermark and edl_created_at columns not found.")

            newDF = df.withColumn("rn", row_number().over(W)).filter((col("rn") == lit(1))) \
                .drop("rn")

            # Removing all the records which comes with Op column as "D" in latest data
            # since these are deleted from On-Prem Source Table
            global_opColumn = Config.get('Datalake', 'datalake.operation.column')
            opColumn = tableDetails['OperationColumn'] if 'OperationColumn' in tableDetails.key() else global_opColumn
            if Del:
                df1 = newDF.filter(col(opColumn) != lit("D"))
            else:
                df1 = newDF
            return df1
        else:
            return df

    @staticmethod
    def writeDataIntoS3(df, path: str, mode="append", PartitionBy=None, dataFormat='parquet', Options=None):
        """
        Write Data into AWS S3 Path.
        :param df: spark dataframe.
        :param path: s3 output or target path.
        :param mode: Write mode, Possible values are "append", "ignore", "error", "overwrite". [default -'append'].
        :param PartitionBy: Partition by column name. [default - None].
        :param dataFormat: data format. Possible format parquet, json, csv, avro, orc. [default - Parquet]
        :param Options:  Custom Spark write options. [default - None].

        :return status ['Success'|'Failed']
        """
        try:
            mode = mode.strip().lower()
            if mode not in ["append", "ignore", "error", "overwrite"]:
                msg = f"Input write mode {mode} is invalid."
                logs.error(msg)
                raise ValueError(msg)

            if Options is None:
                Options = {}
            elif not isinstance(Options, dict):
                msg = f"Invalid Options datatype found. dict was expected."
                logs.error(msg)
                raise ValueError(msg)

            if PartitionBy is not None:
                if isinstance(PartitionBy, list):
                    PartCols = PartitionBy
                elif isinstance(PartitionBy, str):
                    PartCols = [x.strip() for x in PartitionBy.split(',')]
                else:
                    msg = f"Invalid PartitionBy type found --->{PartitionBy}. str or list type was expected."
                    logs.error(msg)
                    raise ValueError(msg)
                df.write.partitionBy(PartCols).format(dataFormat.lower()).mode(mode).options(**Options).save(path)
            else:
                df.write.format(dataFormat.lower()).mode(mode).options(**Options).save(path)

            return "Success"
        except Exception as e:
            logs.error(str(e))
            return ("Failed -" + str(e))

    @staticmethod
    def writeDataIntoS3CatalogTable(spark, df, path: str, schema, table, PartitionBy=None, mode="append", db_name="default", dataFormat='hudi', Options=None):
        """
        Write Data into AWS S3 Path.
        :param table:
        :param db_name:
        :param df: spark dataframe.
        :param path: s3 output or target path.
        :param mode: Write mode, Possible values are "append", "ignore", "error", "overwrite". [default -'append'].
        :param PartitionBy: Partition by column name. [default - None].
        :param dataFormat: data format. Possible format parquet, json, csv, avro, orc. [default - Parquet]
        :param Options:  Custom Spark write options. [default - None].

        :return status ['Success'|'Failed']
        """
        try:
            if dataFormat.strip().lower() == "hudi":
                print('hudi implementation')
                hudi_options = {
                    # ---------------DATA SOURCE WRITE CONFIGS---------------#
                    'hoodie.datasource.hive_sync.skip_ro_suffix': 'false',  # to remove _ro suffix from files that are written
                    'hoodie.datasource.hive_sync.use_jdbc': 'false',  # true if JDBC destination
                    "hoodie.datasource.hive_sync.database": db_name,  # databasename to be written to in glue catalog
                    "hoodie.table.name": "hudi_test",  # table to be created/appended to
                    "hoodie.datasource.write.recordkey.field": "customer_id",  # Value to be used as the recordKey component of HoodieKey
                    "hoodie.datasource.write.precombine.field": "updated_at",  # if duplicates exist, record against largest value of precombined field is picked
                    "hoodie.datasource.write.partitionpath.field": "updated_at",  # partition into folders
                    "hoodie.datasource.write.hive_style_partitioning": "true",  # for <partition_column_name>=<partition_value> format while partitioning
                    "hoodie.upsert.shuffle.parallelism": 1,
                    "hoodie.insert.shuffle.parallelism": 1,
                    "hoodie.consistency.check.enabled": True,  # Enabled to handle S3 eventual consistency issue. This property is no longer required since S3 is now strongly consistent.
                    "hoodie.index.type": "BLOOM",
                    "hoodie.index.bloom.num_entries": 60000,  # number of records in a file
                    "hoodie.index.bloom.fpp": 0.000000001,  # Error rate allowed given the number of entries. Used to calculate how many bits should be assigned for the bloom filter
                    "hoodie.cleaner.commits.retained": 2,  #
                    'hoodie.datasource.hive_sync.enable': 'true'  # register/sync the table to Apache Hive metastore
                }
                df.write.format("org.apache.hudi").options(**hudi_options).mode(mode).save("{}/{}/{}".format(path, schema, table))

            else:
                if PartitionBy != None:
                    df.write.partitionBy(PartitionBy).format(dataFormat.lower()).mode(mode).save("{}/{}/{}".format(path, schema, table))
                else:
                    df.write.format(dataFormat.lower()).mode(mode).save("{}/{}/{}".format(path, schema, table))

                    #write to glue catalog
                    spark.sql(f"CREATE DATABASE IF NOT EXISTS {db_name} LOCATION 's3://empower-foundation-staging-bucket/user/'")
                    df.write.format(dataFormat.lower()).saveAsTable(f'`{db_name}`.{table}', mode=mode)


                    # database_name = "data-ingestion-demo"
                    # # catalog_table_path = f"glue_catalog:{database_name}.{table}"
                    # catalog_table_path = f"{database_name}.{table}"
                    # df.write.format("parquet").mode(mode).option("path", catalog_table_path).save()
                    # df.repartition(1).write.option("path","s3://testbucket/testpath/").mode(mode).saveAsTable("emrdb.testtableemr")

        except Exception as e:
                    logs.error(str(e))
                    return ("Failed -" + str(e))

        return "Success"
        # try:
        #     if mode == 'append':
        #
        #         # dydf = DynamicFrame.fromDF(df, glueContext, "dydf")
        #         #
        #         # sink = glueContext.getSink(connection_type="s3", path="{}/{}/{}".format(path,schema,table),
        #         #     enableUpdateCatalog=True, updateBehavior="UPDATE_IN_DATABASE",
        #         #     partitionKeys=PartitionBy)
        #         # format_options={"useGlueParquetWriter": True}
        #         # sink.setFormat("parquet",**format_options)
        #         # sink.setCatalogInfo(catalogDatabase=schema, catalogTableName=table)
        #         # sink.writeFrame(dydf)
        #         if PartitionBy != None:
        #             df.write.partitionBy(PartitionBy).format(dataFormat.lower()).mode('overwrite').save("{}/{}/{}".format(path,schema,table))
        #         else:
        #             df.write.format(dataFormat.lower()).mode('overwrite').save("{}/{}/{}".format(path,schema,table))
        #     else:
        #         # dydf = DynamicFrame.fromDF(df, glueContext, "dydf")
        #         #
        #         # sink = glueContext.getSink(connection_type="s3", path="{}/{}/{}".format(path,schema,table),
        #         #     enableUpdateCatalog=True, updateBehavior="UPDATE_IN_DATABASE",
        #         #     partitionKeys=PartitionBy)
        #         # format_options={"useGlueParquetWriter": True}
        #         # sink.setFormat("parquet",**format_options)
        #         # sink.setCatalogInfo(catalogDatabase=schema, catalogTableName=table)
        #         # sink.writeFrame(dydf)
        #         if PartitionBy != None:
        #             df.write.partitionBy(PartitionBy).format(dataFormat.lower()).mode('overwrite').save("{}/{}/{}".format(path,schema,table))
        #         else:
        #             df.write.format(dataFormat.lower()).mode('overwrite').save("{}/{}/{}".format(path,schema,table))
        #     print("Returning Success")
        #     return "Success"
        # except Exception as e:
        #     logs.error(str(e))
        #     return ("Failed -" + str(e))

    # If target Database is RedShit then it is always recommended to use Dynamic Frame for writing data into RedShift.
    # instead of Spark DataFrame. Use below method to writing data into pass table.
    @staticmethod
    def writeIntoRedshift(glueContext, df, table_name, secret_json,Options,
                          mode='append', PrimaryColumns=None, preQry=None, postQry=None, region_name='ap-south-1'):
        """
        Write Data into Redshift table using glue context.
        :param glueContext: Glue Context.
        :param df: spark dataframe.
        :param Config: Config object of properties file.
        :param source: Source defined in TableMaster for input table to get all table level detail.
        :param schema: Redshift table schema name.
        :param table_name: Redshift table name.
        :param secret_name: AWS Secret manager name to get database credentials.
        :param mode: Write mode, Possible values are "append", "truncate_write", "drop_write", "upsert". [default -'append'].
        :param PrimaryColumns: Redshift table Primary Columns. Require for Upsert mode only. [default -None].
        :param preQry: Pre-Query that need to be execute before running Copy command. [default -None].
        :param postQry: Post-Query that need to be execute after successfully completion of Copy command. [default -None].
        :param region_name:  AWS Secret manager region name. [default - 'ap-south-1']

        :return status ['Success'|'Failed']
        """
        batchId = str(F.EpochTime())
        try:
            #secret1 = Sr.getSecret(secret_name, region_name=region_name)
            if 'engine' not in secret_json.keys():
                secret_json['engine'] = 'redshift'
            secret, Properties = F.getProperties(secret_json)
        except Exception as e:
            logs.error(e, exc_info=True)
            return "Failed"
        glueConnectionName = Options['glueConnectionName']
        tempPath = Options['tempPath']
        schema = Options['schema']
        table = str(schema) + str(".") + str(table_name)
        target_table = table
        preAction = None
        postAction = None
        logs.info("::::Table Name is {}".format(table))
        logs.info(f"::::Connecting to URL {secret['url']}.")
        if mode.lower() in ("truncate_write", "overwrite"):
            preAction = (str(preQry) + ';' if preQry is not None else '') + f"truncate table {table};"
            postAction = postQry
            target_table = table
        elif mode.lower() == "drop_write":
            preAction = (str(preQry) + ';' if preQry is not None else '') + f"drop table if exists {table};"
            postAction = postQry
            target_table = table
        elif mode.lower() == "append":
            preAction = preQry
            postAction = postQry
            target_table = table
        elif mode.lower() == "upsert":
            if PrimaryColumns is None:
                logs.warning("Primary Key not found")
                return "Failed"
            Wh = ""
            stage_table = f'{schema}.stg_{table_name}'
            target_table = stage_table
            preQry = f"truncate table {stage_table};"
            for x in PrimaryColumns:
                if Wh == "":
                    Wh = f"{table}.{x} = {stage_table}.{x}"
                else:
                    Wh = Wh + f" and {table}.{x} = {stage_table}.{x}"
            postQry = f"begin; delete from {table} using {stage_table} where {Wh}; insert into {table} select * from {stage_table}; drop table {stage_table}; end;"
            preAction = preQry
            postAction = postQry
        else:
            msg = f"Input write mode {mode} is invalid."
            logs.error(msg)
            raise ValueError(msg)
        try:

            if mode.lower() in ('overwrite','upsert'):
                df1 = df.limit(1)
                df1.write.format('jdbc').options(
                    url=secret['url'],
                    driver='com.amazon.redshift.jdbc42.Driver',
                    dbtable=target_table,
                    user=secret['username'],
                    password=secret['password']).mode('overwrite').save()

            conn_options = {"dbtable": target_table, "database": secret['dbname']}
            if preAction is not None:
                conn_options['preactions'] = preAction

            if postAction is not None:
                conn_options['postactions'] = postAction

            logs.info("::::Pre Action Query is {}".format(preAction))
            logs.info("::::Post Action Query is {}".format(postAction))

            datasource0 = DynamicFrame.fromDF(df, glueContext, "datasource0")
            glueContext.write_dynamic_frame.from_jdbc_conf(frame=datasource0,
                                                        catalog_connection=glueConnectionName,
                                                        connection_options=conn_options,
                                                        redshift_tmp_dir=tempPath)
            return "Success"
        except Exception as e:
            logs.error(e, exc_info=True)
            return "Failed"

    # Method to write data into RDS (Postgres). By default it append data, We can pass Mode as Overwrite for truncate
    # and write. The option truncate -> true is only applicable when we overwrite data. If it is true then it will
    # truncate table and write new data and if it is false then it will drop table and create new table with new records.
    # Possible Mode value are "append"(default), "truncate_write", "drop_write"
    @staticmethod
    def writeUsingJDBC(spark, Config, df, source, schema, table_name, secret_json,
                       mode="append", Options=None, region_name='ap-south-1', PrimaryColumns=None):
        """
        Write Data into relational Database table through spark JDBC connection.
        :param spark: spark Session.
        :param Config: Config object of properties file.
        :param df: Input dataframe.
        :param source: Source defined in TableMaster for input table to get all table level detail.
        :param schema: target table schema name.
        :param table_name: target table name.
        :param secret_name: AWS Secret manager name to get database credentials.
        :param mode: Write mode, Possible values are "append", "truncate_write", "drop_write", "upsert",
        "ignore", "error", "overwrite". [default -'append'].
        :param Options: Additional Spark JDBC Options[default - None]
        :param PrimaryColumns: Redshift table Primary Columns. Require for Upsert mode only. [default -None].
        :param region_name:  AWS Secret manager region name. [default - 'ap-south-1']

        :return status ['Success'|'Failed']
        """
        batchId = str(F.EpochTime())
        InputMode = mode
        logs.info(f"Input mode {InputMode} enabled.")
        try:
            #secret1 = Sr.getSecret(secret_name, region_name=region_name)
            if 'engine' not in secret_json.keys():
                engineFound = False
                Engine = None
                if Config.has_section('Environment'):
                    if Config.has_option('Environment', 'default.database.engine'):
                        Engine = Config.get('Environment', 'default.database.engine')
                        engineFound = True
                if not engineFound:
                    engMsg = f"database Engine type not found in secrets. Either defined it in Secret or " \
                             f"else enable the properties 'default.database.engine' in 'Environment' Section " \
                             f"of Config.properties file. " \
                             f"Possible Engine types are postgres, redshift, mysql and oracle."
                    logs.error(engMsg)
                    raise ValueError(engMsg)
            else:
                Engine = secret_json['engine']

            if Engine.lower() == 'redshift':
                logs.error("For Redshift use 'writeIntoRedshift' method instead 'writeUsingJDBC'.")
            secret, Properties = F.getProperties(secret_json, engine=Engine)
        except Exception as e:
            logs.error(e, exc_info=True)
            return "Failed"
        try:
            table = str(schema) + str(".") + str(table_name)
            target_table = table
            upsert_mode = False
            truncate = "true"
            if mode.lower() == "truncate_write":
                mode = "overwrite"
                truncate = "true"
                target_table = table
            elif mode.lower() == "drop_write":
                mode = "overwrite"
                truncate = "false"
                target_table = table
            elif mode.lower() == "upsert":
                upsert_mode = True
                target_table = f'{table}_{batchId}'
                if (PrimaryColumns is None or
                        (not isinstance(PrimaryColumns, list) and not isinstance(PrimaryColumns, str)) or
                        (isinstance(PrimaryColumns, str) and str(PrimaryColumns).strip() == '') or
                        (isinstance(PrimaryColumns, list) and len(PrimaryColumns) == 0)):
                    logs.warning("Primary Key not found. Getting it from TableMaster")
                    JsonPath = Config.get('Environment', 's3.table.master.path')
                    table_details = JobUtils.getTableDetails(spark, JsonPath, source, schema, table_name, mode='spark')
                    if ((isinstance(table_details["PrimaryColumns"], list) and
                         len(table_details["PrimaryColumns"]) == 0) or
                            (table_details["PrimaryColumns"] is None)
                    ):
                        msg1 = f"Primary Key can not be Null with Upsert mode. Either pass primary colums as a Input or " \
                               f"defined in TableMaster.json file"
                        logs.error(msg1)
                        raise ValueError(msg1)
                    else:
                        PrimaryColumns = table_details["PrimaryColumns"]
                    mode = "overwrite"
            elif mode.strip().lower() not in ["append", "ignore", "error", "overwrite"]:
                msg = f"Input write mode {mode} is invalid."
                logs.error(msg)
                raise ValueError(msg)

            logs.info(f"::::Writing data into Table {target_table} with Batch Id {batchId}")
            logs.info(f"{InputMode} is Enabled")
            default_properties = {"url": secret['url'], "dbtable": target_table,
                                  "numPartitions": 10, "batchsize": 10000, "truncate": truncate}
            print("Options Recieved")
            print(Options)
            if Options is not None:
                Prop = dict(list(default_properties.items()) + list(Properties.items()) + list(Options.items()))
            else:
                Prop = dict(list(default_properties.items()) + list(Properties.items()))
            logs.info("::: Final Options for Writing to Target {}".format(json.dumps(Prop)))
            df.repartition(Prop['numPartitions']).write.format("jdbc").mode(mode.strip().lower()).options(**Prop).save()
            if upsert_mode:
                dbObj = cf.getDbClass(dbEngine=Engine, secret_name=secret_name)
                res = dbObj.UpsertData(table=table, batchId=batchId, PKCols=PrimaryColumns)
                return res
            else:
                return 'Success'
        except Exception as e:
            logs.error(e, exc_info=True)
            return "Failed"

    # Method to read manually State maintained other than Job bookmark. It will read last process state and return state
    # along with Column Name and Flag. If State not found for table then it might be first time load or Full Load table,
    # in that case Flag will be True.
    @staticmethod
    def getPreviousStates(spark: SparkSession, Config, JobName, Schema, Table, watermark_columns):
        """
        Read previous state of job for a particular source, schema and table. If state not set then full load flag will
        be True otherwise it will be False. If it return Full laod as True then use input table dataframe as it is
        otherwise filter the records as 'df.filter(WColumn) > edl_state'.
        :param spark: spark Session.
        :param Config: Config object of properties file.
        :param JobName: Job Name.
        :param Source: Source defined in TableMaster for input table to get all table level detail.
        :param Schema: Table schema name(as per Table Master json).
        :param Table: table name.

        :return full load flag, Watermark Column Name, Watermark last value set
        """
        if Config.has_section('Environment'):
            if Config.has_option('Environment', 'S3.table.state.path'):
                Path = Config.get('Environment', 'S3.table.state.path') + f"JobName={JobName}/Schema={Schema}/Table={Table}"
                msg1 = ""
            else:
                Path = None
                msg1 = '''The state path not found. Properties 'S3.table.state.path' of Section 'Environment' 
                           is either not set or blank. Please set S3 path to store job states in Properties file.'''
                logs.error(msg1)

        StateSchema = StructType([StructField('watermark_col_name', StringType()),
                                    StructField('watermark_col_val', StringType()),
                                    StructField('JobName', StringType()),
                                    StructField('Schema', StringType()),
                                    StructField('Table', StringType())])

        if F.s3_Path_Exists(Path):
            stateDF = spark.read.parquet(Path)
            edl_state = {}
            State = []
            logs.info("State DF :::: ")
            # stateDF.show(truncate=False)
            for watermark_column in watermark_columns:
                logs.info(f"watermark_column :::: {watermark_column}")
                edl_state[watermark_column] = stateDF.filter(f"watermark_col_name = '{watermark_column}'").agg(max(col("watermark_col_val"))).collect()[0][0]
                State = State + [(watermark_column, edl_state[watermark_column], JobName, Schema, Table)]

            new_stateDF = spark.createDataFrame(data=State, schema=StateSchema)

            FullLoad = False

        else:
            FullLoad = True
            State = []
            for watermark_column in watermark_columns:
                State = State + [(watermark_column, None, JobName, Schema, Table)]
            new_stateDF = spark.createDataFrame(data=State, schema=StateSchema)
            edl_state = None

        return new_stateDF, edl_state, FullLoad

    @staticmethod
    def getPreviousStatesUsingAPI(spark: SparkSession, Config, JobName, Schema, Table, watermark_columns):
        get_state_api = None
        if Config.has_section('Environment'):
            if Config.has_option('Environment', 'state.api.url') and Config.has_option('Environment', 'get.state.api.endpoint'):
                state_url = Config.get('Environment', 'state.api.url')
                get_state_endpoint = Config.get('Environment', 'get.state.api.endpoint')
                get_state_api = state_url + get_state_endpoint
                msg1 = ""
            else:
                msg1 = '''The state url not found. Properties 'state.api.url' of Section 'Environment' 
                           is either not set or blank. Please set url in Properties file.'''
                logs.error(msg1)
        else:
            msg = "'Environment' section is not found in Properties file."
            raise ValueError(msg)

        StateSchema = StructType([StructField('watermark_col_name', StringType()),
                                  StructField('watermark_col_val', StringType()),
                                  StructField('JobName', StringType()),
                                  StructField('Schema', StringType()),
                                  StructField('Table', StringType())])

        if get_state_api is not None and get_state_api.strip() != '':  # if state already exists in tables
            # stateDF = spark.read.parquet(Path)
            request_body = {"pipeline": f"{JobName}-{Schema}-{Table}", "table_name": Table, "column_name": watermark_columns}
            logs.info(f'State API url ::: {get_state_api}')
            logs.info(f'Request body ::: {request_body}')

            state = requests.request("POST", get_state_api, headers={'Content-Type': 'application/json'}, json=request_body)
            # state = {"status":200,"message":"Pipeline state fetched successfully","data":{"id":4,"pipeline":"Empower_Ingestion_Framework-customer_data","table_name":"customer_data","column_name":"updated_at, jrn_dt","column_value":"2000-05-01 11:10:01.101","execution_timestamp":"2023-05-17T02:00:01.000Z","created_at":"1684308589915","created_by":"system"}}
            # state = {"status":400,"message":"Pipeline state fetched successfully","data":{"id":4,"pipeline":"Empower_Ingestion_Framework-customer_data","table_name":"customer_data","column_name":"updated_at, jrn_dt","column_value":"2000-05-01 11:10:01.101","execution_timestamp":"2023-05-17T02:00:01.000Z","created_at":"1684308589915","created_by":"system"}}
            response_status = state.status_code  # 200
            response_body = state.json()  # state
            logs.info(f'State API response ::: {state}')
            logs.info(f'State API status ::: {response_status}')
            logs.info(f'State API body ::: {response_body}')
            # logs.info(f'State API text ::: {state.text}')
            if response_status == 200:
                status = response_body['status']
                if status == 200:
                    # state found
                    edl_state = response_body['data']['column_value']
                    logs.info(f"Get State  response :::: {state}")
                    State = [(watermark_columns, edl_state, JobName, Schema, Table)]
                    stateDF = spark.createDataFrame(data=State, schema=StateSchema)
                    FullLoad = False
            elif response_status == 404:
                # full load
                edl_state = None
                State = [(watermark_columns, edl_state, JobName, Schema, Table)]
                stateDF = spark.createDataFrame(data=State, schema=StateSchema)
                FullLoad = True
                # else:
                #     raise ValueError(f"API non 200 Status code : {status}")
            else:
                raise ValueError(f"Http non 200 Status code : {response_status}")

        else:
            raise ValueError("API URL could not be set")

        return stateDF, edl_state, FullLoad

    @staticmethod
    def setStatesUsingAPI(Config, job_start_time, JobName, Schema, Table, watermark_columns, updated_watermark_col_val):
        """
        Write current job states into configure s3 state path.
        :param Config: Config object of properties file.
        :param df: Input state dataframe.The dataframe that return from getCurrentStates method.

        :return status ['Success'|'Failed']
        """
        set_state_api = None
        if Config.has_section('Environment'):
            if Config.has_option('Environment', 'state.api.url') and Config.has_option('Environment', 'get.state.api.endpoint'):
                state_url = Config.get('Environment', 'state.api.url')
                set_state_endpoint = Config.get('Environment', 'set.state.api.endpoint')
                set_state_api = state_url + set_state_endpoint
                msg1 = ""
            else:
                msg1 = '''The state url not found. Properties 'state.api.url' of Section 'Environment' 
                           is either not set or blank. Please set url in Properties file.'''
                logs.error(msg1)
        else:
            msg = "'Environment' section is not found in Properties file."
            raise ValueError(msg)
        request_body = {
                        "pipeline": f"{JobName}-{Schema}-{Table}"
                        , "table_name": Table
                        , "column_name": watermark_columns
                        , "column_value": updated_watermark_col_val
                        , "execution_timestamp": job_start_time
                        }
        logs.info(f'State API url ::: {set_state_api}')
        logs.info(f"Request ::: {request_body}")

        state = requests.request("POST", set_state_api, headers={'Content-Type': 'application/json'}, json=request_body)
        logs.info(f"status ::: {state.status_code}")
        # check state response code and response body status code to pass "Success"
        if state.status_code == 201:
            logs.info("State set successfully")
            return "Success"
        logs.info("State set unsuccessful")
        return "Failed"
        # try:
        #     logs.info("Current Job run states is ..")
        #     df.show(truncate=False)
        #     df.write.partitionBy("JobName", "Schema", "Table").mode("append").parquet(StatePath)
        #     return 'Success'
        # except Exception as e:
        #     logs.error('Error occur while write state into S3.')
        #     logs.error(e)
        #     return 'Failed'


    # Method to return State Dataframe for the input final dataframe and Table.
    @staticmethod
    def getStateDF(spark, Config, df, JobName, Source, Schema, Table):
        """
        Write current job state into configure state path.
        :param spark: spark Session.
        :param Config: Config object of properties file.
        :param df: Input table dataframe (after read data).
        :param JobName: Job Name.
        :param Source: Source defined in TableMaster for input table to get all table level detail.
        :param Schema: Table schema name(as per Table Master json).
        :param Table: table name.

        :return current states dataframe
        """
        if Config.has_section('Environment'):
            if Config.has_option('Environment', 's3.table.master.path'):
                JsonPath = Config.get('Environment', 's3.table.master.path')
                msg = ""
            else:
                JsonPath = None
                msg = '''The Table Master path not found. Properties 's3.table.master.path' of Section 'Environment' 
                             is  either not set or blank. Please set S3 path of table master json file in Properties file.'''
                logs.error(msg)
            if JsonPath is None:
                raise ValueError(msg)
        else:
            msg = "'Environment' section is not found in Properties file."
            raise ValueError(msg)
        JobRun = F.TimeNow()
        StateSchema = StructType([StructField('Source', StringType()),
                                  StructField('Schema', StringType()),
                                  StructField('Table', StringType()),
                                  StructField('JobRunTime', StringType()),
                                  StructField('edl_created_at', LongType()),
                                  StructField('Watermark', StringType()),
                                  StructField('JobName', StringType())])
        JsonDF = spark.read.option("multiLine", "true").json(JsonPath) \
            .filter((col("Schema") == lit(Schema)) & (trim(col("Table")) == lit(Table))) \
            .filter(trim(col("StateColumn")) != "")

        if JsonDF.count() > 0:
            WColumn = JsonDF.select(col("StateColumn")).collect()[0][0]
            MaxValue = df.agg(max(col("edl_created_at")), max(col(WColumn))).collect()[0]
            edl_created_at = int(MaxValue[0])
            Watermark = str(MaxValue[1])
            logs.info(
                ":::Debug Table {}, WColumn {}, edl_created_at {}, Watermark {}".format(Table, WColumn, edl_created_at,
                                                                                        Watermark))
            State = [(Source, Schema, Table, JobRun, edl_created_at, Watermark, str(JobName).upper())]
        else:
            edl_created_at = df.agg(max(col("edl_created_at"))).collect()[0][0]
            State = [(Source, Schema, Table, JobRun, edl_created_at, '2000-01-01 00:00:00.000', str(JobName).upper())]

        stateDF = spark.createDataFrame(data=State, schema=StateSchema) \
            .withColumn("Watermark", col("Watermark").cast("Timestamp"))

        return stateDF

    # Method to append State data with into S3 Bucket.
    @staticmethod
    def writeJobStates(Config, df):
        """
        Write current job states into configure s3 state path.
        :param Config: Config object of properties file.
        :param df: Input state dataframe.The dataframe that return from getCurrentStates method.

        :return status ['Success'|'Failed']
        """
        if Config.has_section('Environment'):
            if Config.has_option('Environment', 'S3.table.state.path'):
                StatePath = Config.get('Environment', 'S3.table.state.path')
                msg = ""
            else:
                StatePath = None
                msg = '''The state path not found. Properties 'S3.table.state.path' of Section 'Environment' 
                           is either not set or blank. Please set S3 path to store job states in Properties file.'''
                logs.error(msg)
            if StatePath is None:
                raise ValueError(msg)
        else:
            msg = "'Environment' section is not found in Properties file."
            raise ValueError(msg)

        logs.info(":::Writing Job state to the path {}".format(StatePath))
        try:
            logs.info("Current Job run states is ..")
            # df.show(truncate=False)
            df.write.partitionBy("JobName", "Schema", "Table").mode("append").parquet(StatePath)
            return 'Success'
        except Exception as e:
            logs.error('Error occur while write state into S3.')
            logs.error(e)
            return 'Failed'

    # Method to Write data into DynamoDB Table. It is recommended to keep target Dynamodb Tables at On-demand mode to
    # get good write performance.
    @staticmethod
    def writeIntoDynamoDb(GlueContext, df, Table):
        """
        Write data into DynamoDB table using Glue Context.
        :param GlueContext: Glue Context.
        :param df: Input dataframe.
        :param Table: DynamoDb table name.

        :return status ['Success'|'Failed']
        """
        logger = GlueContext.get_logger()
        try:
            dydf = DynamicFrame.fromDF(df, GlueContext, "dydf")
            logger.info("::::Writing Dataframe data into Dynamodb table {}".format(Table))

            GlueContext.write_dynamic_frame.from_options(frame=dydf,
                                                         connection_type="dynamodb",
                                                         connection_options={"tableName": Table}
                                                         )
            return "Success"
        except Exception as e:
            logger.error(e)
            return ("Failed -" + str(e))
