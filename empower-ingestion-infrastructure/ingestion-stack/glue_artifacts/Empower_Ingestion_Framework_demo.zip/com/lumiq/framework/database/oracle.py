from com.lumiq.framework.utils.SecretUtils import SecretUtils as Sr
import cx_Oracle as cx
import logging as logs


class OracleConnect(object):
    def __init__(self, secret_name):
        self.secret_name = secret_name

    def getDetails(self):
        details = Sr.getSecret(secret_name=self.secret_name)
        if not isinstance(details, dict):
            msg = f"Invalid Secret Found {self.secret_name}"
            logs.error(msg)
            raise ValueError(msg)
        else:
            return details
    dbEngine = 'oracle'

    @staticmethod
    def getConnection(details=None):
        if details is None:
            details = OracleConnect.getDetails
        dsn_tns = cx.makedsn(details['host'], str(details['port']), service_name=details['dbname'])
        connection = cx.connect(user=details['username'], password=details['password'], dsn=dsn_tns, encoding='UTF-8')
        return connection

    @staticmethod
    def runQuery(Query, connection=None):
        try:
            if connection is None:
                logs.info("Connection to Database.")
                connection = OracleConnect.getConnection()
            logs.info("::::Running SQL Query.")
            cur = connection.cursor()
            logs.info("""::::Executing SQL Query "{}" to Database.""".format(str(Query)))
            cur.execute(Query)
            logs.info("::::Query Execution is done.")
            if Query.startswith("DELETE"):
                rows = cur.rowcount
            else:
                rows = 0
            connection.commit()
            logs.info(":::: Committing Changes to Database.")
            cur.close()
            # connection.close()
            return ("Success", rows)
        except (Exception, cx.DatabaseError) as e:
            logs.error(":::: {}".format(e))
            if connection is not None:
                connection.close()
            return ("Failed -" + str(e), 0)
        except Exception as e:
            logs.error(":::: {}".format(e))
            if connection is not None:
                connection.close()
            return ("Failed -" + str(e), 0)


    @staticmethod
    def tableExists(connection, schema, table):
        cursor = connection.cursor()
        sql2 = f"SELECT EXISTS (SELECT 1 FROM information_schema.tables " \
               f"WHERE table_schema = '{schema}' AND table_name = '{table}')"
        cursor.execute(sql2)
        exists = cursor.fetchall()[0][0]
        if not exists:
            cursor.close()
            return False
        else:
            sql3 = f"SELECT count(*) FROM {schema}.{table}"
            cursor.execute(sql3)
            record = cursor.fetchall()[0][0]
            cursor.close()
            if record == 0:
                return False
            else:
                return True

    @staticmethod
    def getUpsertQry(table, batchId, PKCols):
        Wh = ""
        stage_table = f'{table}_{batchId}'
        for x in PKCols:
            if Wh == "":
                Wh = f"main.{x} = stage.{x}"
            else:
                Wh = Wh + f" and main.{x} = stage.{x}"
        Qry = f'''BEGIN; 
                  DELETE FROM {table} main 
                  USING  {stage_table} stage
                  WHERE {Wh}; 

                  INSERT INTO {table} 
                  SELECT * FROM {stage_table};
                  END;'''
        return Qry, stage_table

    @staticmethod
    def dropStageTable(connection, stage_table):
        logs.info(f"Dropping Stage table {stage_table}.")
        Qry = f'''DROP TABLE IF EXISTS {stage_table};'''
        if connection is None:
            connection = OracleConnect.getConnection()

        (res, rw) = OracleConnect.runQuery(connection, Qry)
        if str(res).upper() != 'SUCCESS':
            logs.error(f"Error occurred while executing Query {Qry}.")
        logs.info("Closing open connection.")
        res1 = OracleConnect.closeConnection(connection)
        if str(res1).upper() != 'SUCCESS':
            logs.error(f"Error occurred while closing connection.")
        else:
            logs.info("Connection closed.")
        return res

    @staticmethod
    def UpsertData(table, batchId, PKCols, connection=None):
        try:
            if connection is None:
                connection = OracleConnect.getConnection()
            Qry1, stage_table = OracleConnect.getUpsertQry(table=table, batchId=batchId, PKCols=PKCols)
            res1, rws = OracleConnect.runQuery(Query=Qry1, connection=connection)
            final_result = res1
            if res1.upper() == 'SUCCESS':
                res2 = OracleConnect.dropStageTable(stage_table=stage_table)
                final_result = res2
                if res2.upper() != 'SUCCESS':
                    logs.error(f"Error occurred while dropping stage table {stage_table}.")
                else:
                    logs.info(f"Stage table {stage_table} dropped successfully.")
            else:
                logs.info(f"Error occurred while merging data from stage table {stage_table} to main table {table}")

            return final_result
        except Exception as e:
            logs.error(":::: {}".format(e))
            return "Exception"

    @staticmethod
    def closeConnection(connection):
        try:
            if connection is not None:
                connection.close()
            return "Success"
        except Exception as e:
            logs.error(":::: {}".format(e))
            return "Exception"
