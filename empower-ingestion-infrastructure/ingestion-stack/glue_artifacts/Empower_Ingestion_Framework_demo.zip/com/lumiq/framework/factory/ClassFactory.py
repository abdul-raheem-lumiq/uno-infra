import importlib
import pkgutil
import inspect
import com.lumiq.framework.ingest.jobs
import com.lumiq.framework.database


def list_submodules(list_name, package_name):
    for loader, module_name, is_pkg in pkgutil.walk_packages(package_name.__path__, package_name.__name__ + '.'):
        list_name.append(module_name)
        module_name = __import__(module_name, fromlist='dummylist')
        if is_pkg:
            list_submodules(list_name, module_name)


class ClassFactory(object):
    # Method to return Class instance/object as per parameter pass in Glue Job.
    # it get class Name on the basis of Job Name field inside the class. Job Name field should be Unique all Job classes.
    @staticmethod
    def getJobClass(spark, glueContext, Config, jobName):
        if (jobName.strip() == ''):
            raise ValueError("::::Job Name can not be Empty/Null.")

        all_modules = []
        list_submodules(list_name=all_modules, package_name=com.lumiq.framework.ingest.jobs)

        try:
            for module_class in all_modules:
                Path = str(module_class)
                module = importlib.import_module(Path)
                for name, attrq in inspect.getmembers(module, predicate=inspect.isclass):
                    class_Name = getattr(module, name)
                    if hasattr(class_Name, "jobName"):
                        if (class_Name(spark, glueContext, Config).jobName.upper() == jobName.upper()):
                            return class_Name(spark, glueContext, Config)
            raise ValueError("::::Job with name {} not found".format(jobName))
        except (ImportError, AttributeError) as e:
            raise ImportError('::::Class Not Found for the Job Name Passed {}'.format(jobName))

    @staticmethod
    def getDbClass(dbEngine, secret_name):
        if (secret_name.strip() == ''):
            raise ValueError("::::No input Secret Name found.")
        db_modules = []
        list_submodules(list_name=db_modules, package_name=com.lumiq.framework.database)

        try:
            for module_class in db_modules:
                Path = str(module_class)
                module = importlib.import_module(Path)
                for name, attrq in inspect.getmembers(module, predicate=inspect.isclass):
                    class_Name = getattr(module, name)
                    if hasattr(class_Name, "dbEngine"):
                        if (class_Name(secret_name).dbEngine.upper() == dbEngine.upper()):
                            return class_Name(secret_name)
            raise ValueError(":::: Connector for database engine {} not found".format(dbEngine))
        except (ImportError, AttributeError) as e:
            raise ImportError('::::Class Not Found for the Db Engine Name Passed {}'.format(dbEngine))
