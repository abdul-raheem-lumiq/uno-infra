import datetime
from datetime import timedelta
from os import getenv
import json
from airflow import DAG
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.operators.dummy import DummyOperator
from airflow.operators.bash_operator import BashOperator
from airflow.utils.dates import days_ago
from airflow.utils.dates import datetime
from airflow.utils.dates import timedelta
from airflow.models import Variable
from datetime import datetime
import os
import json


DAG_ID = 'hudi_test_dag' #os.path.basename(__file__).replace(".py", "")

with DAG(
        dag_id=DAG_ID,
        schedule_interval='51 19/12 * * *',
        is_paused_upon_creation=True,
        default_args={
            'owner': 'airflow',
            'email': ['airflow@example.com'],
            'email_on_failure': False,
            'email_on_retry': False,
            'depends_on_past': False,
        },
        start_date=datetime.strptime('2023-06-20 19:49:34', "%Y-%m-%d %H:%M:%S")
) as dag:

    start_ingestion_task = DummyOperator(
        task_id='start_ingestion_task'
    )

    end_ingestion_task = DummyOperator(
        task_id='end_ingestion_task'
    )

    json_config = {"source":{"host":"empower-poc-postgres.cepsv5f9ayrr.ap-south-1.rds.amazonaws.com","port":"5432","username":"postgres","password":"b%eG5eI2fK*9","db_name":"postgres","schema":["public"],"engine":"postgres","ssl":False},"destination":{"s3_key":"SAJDVSDYGJAHBSDLA","s3_access_key":"sfdsaajkhduzjvsdfuish/SLKJhJDJAS","s3_bucket_name":"empower-foundation-staging-bucket","s3_directory":"/test/","s3_bucket_region":"ap-south-1","engine":"S3"},"table_mapping":[{"source_table_name":"customer_data","destination_table_name":"customer_data","source_schema":"public","destination_schema":"test","custom_sql":False,"enabled":True,"sync_type":"INA","primary_key":["customer_id"],"cursor_field":"updated_at,jrn_dt","column_config":[{"source_column":"customer_id","destination_column":"customer_id","enabled":True},{"source_column":"name","destination_column":"name","enabled":True},{"source_column":"dob","destination_column":"dob","enabled":True},{"source_column":"gender","destination_column":"gender","enabled":True},{"source_column":"pan","destination_column":"pan","enabled":True},{"source_column":"updated_at","destination_column":"updated_at","enabled":True}]},{"source_table_name":"customer_contact_info","destination_table_name":"customer_contact_info","source_schema":"public","destination_schema":"test","custom_sql":False,"enabled":False,"sync_type":"FRO","primary_key":[""],"cursor_field":"","column_config":[{"source_column":"customer_id","destination_column":"customer_id","enabled":True},{"source_column":"contact_no","destination_column":"contact_no","enabled":True},{"source_column":"address","destination_column":"address","enabled":True},{"source_column":"updated_at","destination_column":"updated_at","enabled":True}]}]}

    json_source_target = {k:v for k,v in json_config.items() if k not in ['table_mapping']}

    for table in (table for table in json_config['table_mapping'] if table['enabled']):

        jsonparams = json.dumps(dict(list(table.items()) + list(json_source_target.items())))
        IncrementalIngestionJob = GlueJobOperator(
            task_id="glue_job_step_" + table['source_table_name'],
            job_name='EMP_Incremental_Ingestion_Job',
            job_desc="triggering glue job IngestionJob",
            region_name='ap-south-1',
            s3_bucket = 'empower-foundation-artifact-bucket',
            concurrent_run_limit = 200,
            create_job_kwargs={"GlueVersion": "3.0", "NumberOfWorkers": 1, "WorkerType": "G.1X", "Timeout": 1800, "Connections": {"Connections": ["ingestion_test"]}},
            iam_role_name='glue-rds-access',
            script_location='s3://empower-foundation-artifact-bucket/glue-artifacts/Main.py',
            script_args={"--conf": "spark.serializer=org.apache.spark.serializer.KryoSerializer --conf spark.sql.hive.convertMetastoreParquet=false --conf spark.jars.packages=org.apache.hudi:hudi-spark-bundle_2.12:0.7.0,org.apache.spark:spark-avro_2.12:3.0.2", "--use-postgres-driver":"True","--jsonparams":jsonparams,"--job-language":"python","--job-bookmark-option":"job-bookmark-disable","--enable-metrics":"True","--enable-continuous-cloudwatch-log":"True","--enable-spark-ui":"True","--enable-glue-datacatalog":"True","--enable-job-insights":"True","--extra-py-files":"s3://empower-foundation-artifact-bucket/glue-artifacts/Empower_Ingestion_Framework_demo.zip","--extra-jars":"s3://empower-foundation-artifact-bucket/glue-artifacts/dependent-jars/hudi-spark3.3-bundle_2.12-0.12.0.jar,s3://empower-foundation-artifact-bucket/glue-artifacts/dependent-jars/spark-avro_2.12-3.0.1.jar,s3://empower-foundation-artifact-bucket/glue-artifacts/dependent-jars/calcite-core-1.33.0.jar,s3://empower-ingestion-rnd/drivers/postgresql-9.2-1003-jdbc4.jar","--extra-files":"s3://empower-foundation-artifact-bucket/glue-artifacts/Config.properties"},
            trigger_rule='all_success',
        )

        start_ingestion_task >> IncrementalIngestionJob >> end_ingestion_task