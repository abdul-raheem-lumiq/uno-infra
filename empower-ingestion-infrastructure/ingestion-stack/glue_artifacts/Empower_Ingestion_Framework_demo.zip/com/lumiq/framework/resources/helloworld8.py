from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from datetime import datetime, timedelta
import json

DAG_ID = 'helloworld8' #os.path.basename(__file__).replace(".py", "")

def hello():
    print("hello world")

with DAG(
        dag_id=DAG_ID,
        schedule_interval='* */2 * * *',
        default_args={
            'owner': 'airflow',
            'email': ['airflow@example.com'],
            'email_on_failure': False,
            'email_on_retry': False,
            'depends_on_past': False,
            'schedule_interval': '* */2 * * *'
        },
        start_date=datetime(2500, 5, 18) # .strptime("2023-05-19 00:01:00" , "%Y-%m-%d %H:%M:%S")
) as dag:
    # start_ingestion_task = PythonOperator(
    #     task_id='start_ingestion_task',
    #     python_callable=hello,
    #     dag=dag
    # )
    start_ingestion_task = DummyOperator(
        task_id='start_ingestion_task'
    )

    json_config = {"source":{"host":"empower-poc-postgres.cepsv5f9ayrr.ap-south-1.rds.amazonaws.com","port":"5432","username":"postgres","password":"b%eG5eI2fK*9","db_name":"postgres","schema":["public"],"engine":"postgres","ssl":False},"destination":{"s3_key":"SAJDVSDYGJAHBSDLA","s3_access_key":"sfdsaajkhduzjvsdfuish/SLKJhJDJAS","s3_bucket_name":"empower-foundation-staging-bucket","s3_directory":"/test/","s3_bucket_region":"ap-south-1","engine":"S3"},"table_mapping":[{"source_table_name":"customer_data","destination_table_name":"customer_data","source_schema":"public","destination_schema":"test","custom_sql":False,"enabled":True,"batched":True, "batch_config": {"batch_size":2000, "number_of_batches/row_count":5} ,"sync_type":"INA","primary_key":["customer_id"],"cursor_field":"updated_at,jrn_dt","column_config":[{"source_column":"customer_id","destination_column":"customer_id","enabled":True},{"source_column":"name","destination_column":"name","enabled":True},{"source_column":"dob","destination_column":"dob","enabled":True},{"source_column":"gender","destination_column":"gender","enabled":True},{"source_column":"pan","destination_column":"pan","enabled":True},{"source_column":"updated_at","destination_column":"updated_at","enabled":True}]},{"source_table_name":"customer_contact_info","destination_table_name":"customer_contact_info","source_schema":"public","destination_schema":"test","custom_sql":False,"enabled":True,"sync_type":"FRO","primary_key":[""],"cursor_field":"","column_config":[{"source_column":"customer_id","destination_column":"customer_id","enabled":True},{"source_column":"contact_no","destination_column":"contact_no","enabled":True},{"source_column":"address","destination_column":"address","enabled":True},{"source_column":"updated_at","destination_column":"updated_at","enabled":True}]}]}

    json_source_target = {k:v for k,v in json_config.items() if k not in ['table_mapping']}

    for table in (table for table in json_config['table_mapping'] if table['enabled']):

        jsonparams = json.loads(json.dumps(dict(list(table.items()) + list(json_source_target.items()))))
        if 'batched' in jsonparams:
            if jsonparams['batched']:
                batch_config = jsonparams['batch_config']
                batch_size = batch_config['batch_size']
                for i in range(batch_config['number_of_batches/row_count']):
                    # print(f"table_{table['source_table_name']}_batch_{i}")
                    glue_ingestion_task = DummyOperator(
                        task_id=f"glue_ingestion_task_{table['source_table_name']}_batch_{i}"
                    )
                    start_ingestion_task >> glue_ingestion_task
        else:
            glue_ingestion_task = DummyOperator(
                task_id=f"glue_ingestion_task_{table['source_table_name']}"
            )


        start_ingestion_task >> glue_ingestion_task
