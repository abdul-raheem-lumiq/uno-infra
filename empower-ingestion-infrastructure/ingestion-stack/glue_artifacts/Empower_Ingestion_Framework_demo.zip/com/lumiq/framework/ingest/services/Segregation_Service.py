import configparser
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from com.lumiq.framework.utils.DFUtils import DFUtils as F
from com.lumiq.framework.utils.JobUtils import JobUtils as Jb
import logging as log
import traceback


class Segregation_Service(object):

    def __init__(self, spark: SparkSession, glueContext, Config: configparser, Source):
        self.Source = Source
        self.spark = spark
        self.glueContext = glueContext
        self.Config = Config

    def Start(self, tableList: list, job_name):
        try:

            Config = self.Config
            spark = self.spark
            Source = self.Source
            glueContext = self.glueContext
            # get path of table's control JSON File
            JsonPath = Config.get('Envirnoment', 's3.table.master.path')
            StatePath = Config.get('Envirnoment', 'S3.table.state.path')

            # Current Timestamp
            job_run_time = F.TimeNow()
            dm_upd_int = F.TimeNow('%Y%m%d%H%M%S')
            UTCDate = F.UTCDateNow()
            FileDate = str(UTCDate.replace("-", ""))

            # Stage Properties
            StageBucket = Config.get("Stage", "stage.bucket.name")
            StagePath = Config.get("Stage", "stage.bucket.path")

            srcDirProp = str(Source) + (".stage.dir")
            srcDir = Config.get(Source, srcDirProp)

            # Raw Properties
            RawBucket = Config.get("Raw", "raw.bucket.name")
            RawPath = Config.get("Raw", "raw.bucket.path")
            tarNonPIIDirProp = str(Source) + (".raw.dir")
            tarNonPIIDir = Config.get(Source, tarNonPIIDirProp)

            # Secure Properties
            SecureBucket = Config.get("Secure", "secure.bucket.name")
            SecurePath = Config.get("Secure", "secure.bucket.path")
            tarPIIDirProp = str(Source) + (".secure.dir")
            tarPIIDir = Config.get(Source, tarPIIDirProp)

            for table in tableList:
                schemaName = str(table.split(",")[0]).strip(' ')
                tableName = str(table.split(",")[1]).strip(' ')
                fullload = str(table.split(",")[2]).strip(' ')

                if fullload == "Y":
                    WriteMode = "overwrite"
                else:
                    WriteMode = "append"
                BucketKey = srcDir + "/" + schemaName + "/" + tableName + "/"
                tablePath = F.s3Path(StagePath + str("/") + BucketKey)

                if F.s3_File_Exists(StageBucket, BucketKey):
                    (Count, BookMarkDF) = Jb.readRawTableUsingGlue(glueContext, Config, Source, schemaName, tableName)
                    if Count > 0:
                        (FullLoad, ColName, edl_state) = Jb.readLookUpTable(spark, StatePath, JsonPath, job_name,
                                                                            Source, schemaName, tableName)

                        if FullLoad:
                            StageDF = BookMarkDF
                            StageCount = Count
                        else:
                            StageDF = BookMarkDF.filter(col(ColName) > lit(edl_state))
                            StageCount = StageDF.count()

                        log.info("::::Return Full Load Flag from State Control Table is {}".format(str(FullLoad)))
                        log.info("::::Incrmental Count from Job Bookmark is {} and from State is {}".format(str(Count),
                                                                                                            str(
                                                                                                                StageCount)))
                        if StageCount > 0:
                            PIIColsList = Jb.getPIIColList(spark, JsonPath, Source, schemaName, tableName)
                            PriColList = Jb.getPrimaryColList(spark, JsonPath, Source, schemaName, tableName)
                            WColumn = Jb.getWatermarkColumn(spark, JsonPath, Source, schemaName, tableName)
                            # log.info("::::PII Columns List for table {} is {}".format(tableName,PIIColsList))
                            # log.info("::::Primary Columns List for table {} is {}".format(tableName, PriColList))
                            StageDF.createOrReplaceTempView("stage_table")
                            TableDF = spark.sql("SELECT *,uuid() as edl_id FROM stage_table") \
                                .withColumn("etl_job_run", lit(job_run_time)) \
                                .withColumn("etl_job_name",  lit(job_name))

                            # rename all columns to Lower Case
                            tableDF = F.toLowerCaseColumnName(TableDF).cache()
                            # tableDF.cache()
                            count = tableDF.count()
                            log.basicConfig()
                            log.getLogger().setLevel(log.INFO)
                            log.info("::::Total Incremental Count for the Table {} is {}".format(tableName, count))
                            if len(PIIColsList) != 0:
                                PIICols = PIIColsList.copy()
                                if WColumn.strip(' ') != "":
                                    PIICols.append(WColumn)
                                PII_Df = tableDF.select("edl_id", *PIICols, "dms_timestamp", "edl_created_at",
                                                        "etl_job_run", "etl_job_name", "op")

                                # If you are using DMS with Data Parition YYYYMMDD then use below Path with FileDate.
                                # SecureBucketKey: str = str(tarPIIDir) + str(schemaName) + "/" + str(
                                #     tableName) + "_PII/" + FileDate + "/"
                                SecureBucketKey: str = str(tarPIIDir) + str(schemaName) + "/" + str(
                                    tableName) + "_PII/"
                                tarPIIPath = F.s3Path(SecurePath + str("/") + SecureBucketKey)

                                Jb.writeDF(PII_Df, tarPIIPath, WriteMode)
                            else:
                                log.warning("::::No PII Columns defined for table {}".format(tableName))

                            PIIColsSet = set(PIIColsList) - set(PriColList)
                            PIIColsSetLower = set(map(lambda x: x.lower(), PIIColsSet))
                            NonPIIColsList = list(set(tableDF.columns) - PIIColsSetLower)

                            NonPII_Df = tableDF.select(*NonPIIColsList)
                            # If you are using DMS with Data Parition YYYYMMDD then use below Path with FileDate.
                            # RawBucketKey: str = str(tarNonPIIDir) + str(schemaName) + str("/") + str(tableName) + str(
                            #     "/") + FileDate + "/"
                            RawBucketKey: str = str(tarNonPIIDir) + str(schemaName) + str("/") + str(tableName) + str(
                                "/") + FileDate + "/"
                            tarNonPIIPath = F.s3Path(RawPath + str("/") + RawBucketKey)

                            Jb.writeDF(NonPII_Df, tarNonPIIPath, WriteMode)
                            stateDF = Jb.writeLookUpTable(spark, tableDF, JsonPath, job_name, Source, schemaName,
                                                          tableName,
                                                          job_run_time)
                            Jb.writeStateDF(stateDF, StatePath)
                            tableDF.unpersist()

                            log.info("::::Table {} of Schema {} has been processed.".format(tableName, schemaName))
                        else:
                            log.warning("::::No Incremental Data found after time {} in a Column {} of a Table {}.{}" \
                                        .format(edl_state, ColName, schemaName, tableName))
                    else:
                        log.warning(
                            "::::No Incremental Data File Found for table {} DataSource is empty".format(tableName))
                else:
                    log.warning("::::Path {} Does not exist!!!".format(tablePath))
            return "Success"
        except Exception as _e:
            log.error(traceback.format_exc())
            return "Failed"
