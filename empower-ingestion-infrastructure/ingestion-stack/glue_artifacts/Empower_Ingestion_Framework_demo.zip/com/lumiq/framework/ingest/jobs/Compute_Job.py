from com.lumiq.framework.ingest.services.Compute_Service import Compute_Service
from com.lumiq.framework.utils.DFUtils import DFUtils as F
from com.lumiq.framework.utils.JobUtils import JobUtils as Jb
import logging as logs

#  Sample Job example to process file by using configure transformation SQL logics.
#  That SQL logic will be mentioned in the Compute.json files and path of Compute.json file will be mentioned in the
#  the properties 'S3.compute.config.path' on Environment Section in Config.properties file.
#  This code is useful when you want to keep SQL Logic outside of code parameters.


class Compute_Job(object):
    def __init__(self, spark, glueContext, Config):
        self.spark = spark
        self.Config = Config
        self.glueContext = glueContext

    def execute(self, args):
        try:
            # Getting required value from parameter
            parameter = str(args['jobName']).strip(' ')
            job_name = parameter.split(",")[0].strip(' ')
            Source = parameter.split(",")[1].strip(' ').upper()
            Source = str(Source)
            Key = parameter.split(",")[2].strip(' ').upper()
            Key = str(Key)
            tableName = Source.lower() + "_" + Key.lower()

            job_id = args['JOB_RUN_ID']
            logs.info("::::Job {} has been started.".format(job_name))

            # ConfigProperties
            BucketPath = self.Config.get('Standard', 'standard.bucket.path')
            StatePath = self.Config.get('Environment', 'S3.table.state.path')

            # Enabling Logs
            logs.basicConfig()
            logs.getLogger().setLevel(logs.INFO)

            # Service object
            obj = Compute_Service(self.spark, self.glueContext, self.Config)

            # Calling Service method
            (res, finalDF, stateDF) = obj.Compute(args)
            finalDF1 = finalDF.cache()
            FCount = finalDF1.count()

            # Auditing
            args['FinalCount'] = str(FCount)
            args['TargetAWSService'] = "S3"

            if FCount > 0:
                OutPath = F.s3Path(BucketPath + Source.upper() + '/' + tableName.upper())
                logs.info("::::Writing Table {} to the Bucket at Path {}".format(tableName, OutPath))
                res1 = Jb.writeDF(finalDF1, OutPath, Mode="append", PartitionBy="id")
                if res1.upper() == "SUCCESS":
                    Jb.writeStateDF(stateDF, StatePath)
                else:
                    logs.error("::::Job has been failed while writing data into S3 Path {}".format(OutPath))

                return res1
            else:
                if res.upper() == "SUCCESS":
                    msg = "No Incremental Data Found in the Source Event Table {}.".format(str(tableName))
                    logs.warning("::::" + msg)
                    return "Warning :- " + msg
                else:
                    return res
        except Exception as e:
            logs.error(e, exc_info=True)
            return ("Failed :-" + str(e))

    # job name keyword
    jobName = "Compute_Job"
