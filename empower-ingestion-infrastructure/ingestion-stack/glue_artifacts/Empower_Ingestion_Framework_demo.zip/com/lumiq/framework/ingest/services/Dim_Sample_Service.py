from com.lumiq.framework.utils.JobUtils import JobUtils as Jb
from com.lumiq.framework.utils.DFUtils import DFUtils as F
from pyspark.sql.functions import *
import logging as log
from pyspark.sql.types import StructType, StructField, StringType, LongType


class Dim_Sample_Service(object):
    def __init__(self, spark, glueContext, Config):
        self.spark = spark
        self.Config = Config
        self.glueContext = glueContext

    def BusinessLogic(self, args):
        spark = self.spark
        Config = self.Config
        glueContext = self.glueContext
        stripMargin = F.strip_margin

        # Enabling log
        log.basicConfig()
        log.getLogger().setLevel(log.INFO)

        # Get path of table's control JSON File
        StatePath = Config.get('Envirnoment', 'S3.table.state.path')
        JsonPath = Config.get('Envirnoment', 's3.table.master.path')

        # Schema and Empty DataFrame creation
        schema = StructType([StructField('col1', StringType(), True)])
        emptyDF = spark.createDataFrame([], schema).cache()

        stateSchema = StructType([StructField('Source', StringType()),
                                  StructField('Schema', StringType()),
                                  StructField('Table', StringType()),
                                  StructField('JobRunTime', StringType()),
                                  StructField('edl_created_at', LongType()),
                                  StructField('Watermark', StringType()),
                                  StructField('JobName', StringType())])
        stateEmptyDF = spark.createDataFrame(spark.sparkContext.emptyRDD(), stateSchema).cache()

        # Current Timestamp
        Run_Time = F.TimeNow()
        dm_upd_int = F.TimeNow('%Y%m%d%H%M%S')

        # GetParametes
        JobName = args['JobName']

        try:
            # Read All Source Table incrementaly using Glue Job Bookmark.
            (JbCount, IncrDF) = Jb.readStandardTableUsingGlue(glueContext, Config, "SOURCE", "SCHEMA", "EMPLOYEE")

            # For Audit
            args["JbCount"] = str(JbCount)
            args['StateCount'] = str(0)
            args['SourceAWSService'] = "S3"

            if JbCount > 0:
                log.info("::::Incremental Count of the table EMPLOYEE is {}".format(JbCount))
                (FirstLoad, Col, state) = Jb.readLookUpTable(spark, StatePath, JsonPath, JobName,"SOURCE", "SCHEMA", "EMPLOYEE")
                if FirstLoad:
                    stateDF = IncrDF
                    stateCount = JbCount
                else:
                    stateDF = IncrDF.filter(col(Col) > lit(state))
                    stateCount = stateDF.count()

                # For Audit
                args['StateCount'] = str(stateCount)
                args['Watermark'] = str(state)

                if stateCount > 0:
                    log.info("::::Starting Business Logic.")
                    stateDF.createOrReplaceTempView("EMPLOYEE")
                    df = spark.sql(stripMargin("""
                                                |SELECT
                                                |id, 
                                                |name, 
                                                |salary,
                                                |state
                                                |FROM (
                                                |    SELECT *,
                                                |        ROW_NUMBER() OVER(PARTITION BY state ORDER BY salary DESC) AS rn
                                                |    FROM EMPLOYEE
                                                |    ) AS A
                                                |WHERE A.rn = 1
                                                |"""))

                    # Adding Audit & Primary Key
                    df1 = df.withColumn("primary_key",col("id"))\
                            .withColumn("edl_job_name", lit(JobName)) \
                            .withColumn("edl_job_run", lit(Run_Time))\
                            .withColumn("dm_upd_int", lit(dm_upd_int).cast("long"))

                    return ("Success", df1, stateDF)

                else:
                    log.warning("::::No new Data found after State Check.")
                    return ("Success", emptyDF, stateEmptyDF)
            else:
                log.warning("::::No Incremental Data Found. DataSource is empty")
                return ("Success", emptyDF, stateEmptyDF)
        except Exception as e:
            log.error(e, exc_info=True)
            return ("Failed -" + str(e), emptyDF, stateEmptyDF)
