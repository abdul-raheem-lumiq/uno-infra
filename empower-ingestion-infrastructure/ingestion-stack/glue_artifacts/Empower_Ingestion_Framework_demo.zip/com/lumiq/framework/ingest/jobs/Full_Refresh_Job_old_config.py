from com.lumiq.framework.ingest.services.Full_Refresh_Service import Full_Refresh_Service
from com.lumiq.framework.utils.DFUtils import DFUtils as F
from com.lumiq.framework.utils.JobUtils import JobUtils as Jb
import logging as logs
import json


class Dim_Sample_Job(object):
    def __init__(self, spark, glueContext, Config):
        self.spark = spark
        self.Config = Config
        self.glueContext = glueContext

    def execute(self, args):
        # Enabling Logs
        logs.basicConfig()
        logs.getLogger().setLevel(logs.INFO)

        try:
            # Getting required value from parameter
            job_name = str(args['JOB_NAME']).strip(' ')
            job_id = args['JOB_RUN_ID']
            logs.info("::::Job {} has been started.".format(job_name))

            print("Recieved Arguments")
            print(args)

            json_param = json.loads(args['jsonparams'])
            table_name = json_param['tableName']

            print('Recieved these JSON Params')
            print(json_param)

            obj = Full_Refresh_Service(self.spark, self.glueContext, self.Config)

            # Calling Service method
            (res, source_df) = obj.readSource(json_param['source'],table_name)
            source_df_count = source_df.count()

            if res.upper() == "SUCCESS" and source_df_count>0:

                logs.info("::::Source Data Ingestion Completed")
                logs.info("::::Count for Data Ingested is {}".format(str(source_df_count)))

                write_res = obj.writeToTarget(source_df,json_param['target'],table_name)

                if write_res.upper() == "SUCCESS":
                    return "SUCCESS"
                else:
                    return write_res

            elif res.upper() == "SUCCESS" and source_df_count == 0:
                logs.info("::::No Data Found in the Table")
            
            else:
                return res
            logs.info("::::Writing Data to Target DB")

            return "SUCCESS"

        except Exception as e:
            logs.error(e, exc_info=True)
            return ("Failed -" + str(e))

    # job name keyword
    jobName = "FullRefreshJob"
