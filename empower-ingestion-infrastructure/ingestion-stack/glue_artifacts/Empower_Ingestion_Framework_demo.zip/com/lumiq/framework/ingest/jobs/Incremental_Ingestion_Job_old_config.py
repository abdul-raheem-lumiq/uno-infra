from com.lumiq.framework.ingest.services.Incremental_Ingestion_Service import Incremental_Ingestion_Service
from com.lumiq.framework.utils.DFUtils import DFUtils as F
from com.lumiq.framework.utils.JobUtils import JobUtils as Jb
from pyspark.sql.types import *
from pyspark.sql.functions import *
import logging as logs
import json


class Dim_Sample_Job(object):
    def __init__(self, spark, glueContext, Config):
        self.spark = spark
        self.Config = Config
        self.glueContext = glueContext

    def execute(self, args):
        # Enabling Logs
        logs.basicConfig()
        logs.getLogger().setLevel(logs.INFO)

        try:
            # Getting required value from parameter
            job_name = str(args['JOB_NAME']).strip(' ')
            job_id = args['JOB_RUN_ID']
            logs.info("::::Job {} has been started.".format(job_name))

            print("Recieved Arguments")
            print(args)

            json_param = json.loads(args['jsonparams'])
            table_name = json_param['tableName']
            primary_keys = json_param['primaryKeys']
            watermark_column = json_param['watermarkColumn']
            incremental_mode = json_param['incrementalMode']

            print('Recieved these JSON Params')
            print(json_param)

            obj = Incremental_Ingestion_Service(self.spark, self.glueContext, self.Config,job_name)

            # Calling Service method

            (res, state_df, source_df, FullLoad) = obj.readSource(json_param['source'],table_name,primary_keys,watermark_column)

            source_df_count = source_df.count()

            if res.upper() == "SUCCESS" and source_df_count>0:

                logs.info("::::Source Data Ingestion Completed")
                logs.info("::::Count for Data Ingested is {}".format(str(source_df_count)))

                new_max_watermark_col = source_df.agg(max(date_format(col(watermark_column),"yyyy-MM-dd HH:mm:ss"))).collect()[0][0]
                new_state_df = state_df.withColumn('watermark_col_val',lit(new_max_watermark_col))

                write_res = obj.writeToTarget(source_df,json_param['target'],table_name,primary_keys,watermark_column,incremental_mode, FullLoad)

                if write_res.upper() == "SUCCESS":
                    # return "SUCCESS"
                    state_res = Jb.writeJobStates(self.Config,new_state_df)
                    return state_res
                else:
                    return write_res

            elif res.upper() == "SUCCESS" and source_df_count == 0:
                logs.info("::::No Data Found in the Table")
                return res
            
            else:
                return res

        except Exception as e:
            logs.error(e, exc_info=True)
            return ("Failed -" + str(e))

    # job name keyword
    jobName = "IncrementalIngestionJob"
