import configparser
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit, to_date, count
from com.lumiq.framework.utils.DFUtils import DFUtils as F
from com.lumiq.framework.utils.JobUtils import JobUtils as Jb
import logging as log
import traceback
import datetime
from datetime import date, timedelta


class Compaction_Service(object):

    def __init__(self, spark: SparkSession, glueContext, Config: configparser):
        self.spark = spark
        self.glueContext = glueContext
        self.Config = Config

    def Start(self, Source, Run):
        try:
            log.info("::::Compaction over Source {} table starting.".format(Source))
            Config = self.Config
            spark = self.spark
            glueContext = self.glueContext
            # get path of table's control JSON File
            JsonPath = Config.get('Envirnoment', 'S3.compaction.table.list')
            StatePath = Config.get('Envirnoment', 'S3.compaction.state.path')

            # Current Timestamp
            job_run_time = F.TimeNow()
            UTCDate = F.UTCDateNow()

            UTCDateTime = datetime.datetime.strptime(UTCDate, '%Y-%m-%d')
            YesterdayDate = UTCDateTime.date() - timedelta(days=1)
            fmt = '%Y%m%d'
            FileDate = int(YesterdayDate.strftime(fmt))
            # Stage Properties
            StageBucket = Config.get("Stage", "stage.bucket.name")
            StagePath = Config.get("Stage", "stage.bucket.path")
            StageTempPath = Config.get("Stage", "stage.bucket.temp.path")
            # StageTempPath = Config.get("Stage", "stage.bucket.temp.path")
            srcDirProp = str(Source) + (".stage.dir")
            srcDir = Config.get(Source, srcDirProp)

            # Raw Properties
            RawBucket = Config.get("Raw", "raw.bucket.name")
            RawPath = Config.get("Raw", "raw.bucket.path")
            RawTempPath = Config.get("Raw", "raw.bucket.temp.path")
            tarNonPIIDirProp = str(Source) + (".raw.dir")
            tarNonPIIDir = Config.get(Source, tarNonPIIDirProp)

            # Secure Properties
            SecureBucket = Config.get("Secure", "secure.bucket.name")
            SecurePath = Config.get("Secure", "secure.bucket.path")
            SecureTempPath = Config.get("Secure", "secure.bucket.temp.path")
            tarPIIDirProp = str(Source) + (".secure.dir")
            tarPIIDir = Config.get(Source, tarPIIDirProp)

            tableList = Jb.getCompactionTableList(spark, JsonPath, Source, Run)

            for table in tableList:
                bucket = str(table.split(",")[0]).strip(' ').upper()
                schemaName = str(table.split(",")[1]).strip(' ')
                tableName = str(table.split(",")[2]).strip(' ')

                Path = ""
                TempPath = ""
                if bucket == "STAGE":
                    Path = StagePath
                    TempPath = StageTempPath
                elif bucket == "RAW":
                    Path = RawPath
                    TempPath = RawTempPath
                elif bucket == "SECURE":
                    Path = SecurePath
                    TempPath = SecureTempPath
                    tableName = tableName + "_PII"

                if Path != "":
                    tablePath = F.s3Path(Path + str("/") + Source.upper() + "/" + schemaName + "/" + tableName)

                    if F.s3_Path_Exists(tablePath):
                        (FirstLoad, LastRunDate) = Jb.readLastRun(spark, StatePath, bucket, Source, schemaName,
                                                                  tableName)
                        log.info("::::{}-First Load Flag for Table {}.{} is {}".format(bucket, schemaName, tableName,
                                                                                       FirstLoad))
                        if FirstLoad:
                            LastRun = date(2021, 1, 15)
                        else:
                            LastRun = datetime.datetime.strptime(str(LastRunDate), '%Y%m%d').date()

                        FileList = Jb.getFileList(tablePath, YesterdayDate, LastRun)

                        if len(FileList) > 0:
                            log.info("::::{}-Path Fetch for  Table {}.{} are {}".format(bucket, schemaName, tableName,
                                                                                        FileList))
                            objCount = F.getObjectCount(tablePath, FileList)
                            log.info("::::{} - Total Objects founds for Table {}.{} are {}".format(bucket, schemaName,
                                                                                                   tableName, objCount))
                            if objCount >= 200:
                                df = spark.read.format("parquet").load(FileList).cache()
                                cc = df.count()
                                log.info(
                                    "::::{}-Total Count of Table {}.{} is {}".format(bucket, schemaName, tableName, cc))

                                part = round(cc / 60000)
                                if part == 0:
                                    part = 1

                                log.info("::::{}-Number of Partition created for Table {}.{} are {}".format(bucket,
                                                                                                            schemaName,
                                                                                                            tableName,
                                                                                                            str(part)))

                                tableTempPath = F.s3Path(
                                    TempPath + str("/") + Source.upper() + "/" + schemaName + "/" + tableName)
                                log.info("::::{}-Table {}.{} Temp Path is {}".format(bucket, schemaName, tableName,
                                                                                     tableTempPath))
                                df.repartition(part).write.mode("overwrite").parquet(tableTempPath)
                                df.unpersist()
                                FinalPath = F.s3Path(tablePath + "/" + str(FileDate))
                                log.info("::::{}-Final Path of Table {}.{} is {}".format(bucket, schemaName, tableName,
                                                                                         FinalPath))
                                spark.read.parquet(tableTempPath).repartition(part).write.mode("overwrite").parquet(
                                    FinalPath)

                                DelPathList = [x for x in FileList if FinalPath not in x]

                                if len(DelPathList) == 0:
                                    log.info("::::{}-No file deletion required for the Table {}.{}".format(bucket,
                                                                                                           schemaName,
                                                                                                           tableName))
                                else:
                                    log.info("::::{}-Files going to delete for the Table {}.{} are {}".format(bucket,
                                                                                                              schemaName,
                                                                                                              tableName,
                                                                                                              DelPathList))
                                    F.delObject(tablePath, DelPathList)

                                stateDF = Jb.createLastRunDF(spark, bucket.upper(), Source, schemaName, tableName,
                                                             job_run_time, FileDate, Run)
                                Jb.writeLastRunDF(stateDF, StatePath)
                            else:
                                log.info(
                                    "::::{}-Total object Found is Less than 100. No Compaction required for Table {}.{}.".format(
                                        bucket, schemaName, tableName))
                        else:
                            log.warning(
                                "::::{}-No New Data Found for the Table {}.{}".format(bucket, schemaName, tableName))
                    else:
                        log.info("::::Table {} does not exist at Path {}".format(tableName, tablePath))
                else:
                    log.error("::::{}-Bucket Parent Path Not Found.".format(bucket))

            return "Success"
        except Exception as _e:
            log.error(traceback.format_exc())
            return "Failed"
