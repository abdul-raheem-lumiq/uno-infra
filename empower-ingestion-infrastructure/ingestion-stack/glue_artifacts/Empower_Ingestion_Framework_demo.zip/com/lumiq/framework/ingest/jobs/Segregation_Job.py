from com.lumiq.framework.ingest.services.Segregation_Service import Segregation_Service
from com.lumiq.framework.utils.JobUtils import JobUtils as Jb
from com.lumiq.framework.utils.JobHelper import JobHelper as Jh
import logging as log


class Separation_Job(object):
    def __init__(self, spark, glueContext, Config):
        self.spark = spark
        self.Config = Config
        self.glueContext = glueContext

    def execute(self, args):
        log.basicConfig()
        log.getLogger().setLevel(log.INFO)

        try:
            GlueJobName = args['JOB_NAME']
            parameter = str(args['jobName']).strip(' ')
            validSource = self.Config.get('Envirnoment', 'source.list')
            srcList = list(map(lambda x: x.strip(' '), validSource.split(",")))
            job_name = parameter.split(",")[0].strip(' ')
            source = parameter.split(",")[1].strip(' ').upper()
            if source not in srcList:
                raise ValueError(
                    "::::Source with name {} not found in valid source list {}.".format(source, str(srcList)))

            if len(parameter.split(",")) == 3:
                fullload = parameter.split(",")[2].strip(' ').upper()

                if fullload == "":
                    fullload = 'N'
                if fullload not in ['N', 'Y', '']:
                    raise ValueError(
                        "::::Full load possible value is 'N', 'Y' or <blank>(''). Value {} found.".format(fullload))
            else:
                fullload = "N"

            obj = Segregation_Service(self.spark, self.glueContext, self.Config, source)
            jsonPath = self.Config.get('Envirnoment', 's3.table.master.path')
            replicaPath = self.Config.get('Envirnoment', 's3.table.list.replica.path')
            StageBucket = self.Config.get('Stage', 'stage.bucket.name')
            SrcDirProperty = str(source) + ".stage.dir"
            SrcDir = self.Config.get(source, SrcDirProperty)

            log.info("::::Job {} has been started.".format(job_name))
            if fullload == 'N':
                log.info("::::Full Load Flag is disable")
                LastJobRun = Jh.fetch_previous_glue_job(GlueJobName)
                log.info("::::Job Last Run is {}".format(LastJobRun))
                TableDict = Jh.fetch_updated_tables_list(LastJobRun, jsonPath, StageBucket, SrcDir, source)
                log.info("::::Modified Tables are {}".format(TableDict))
                tableList = Jb.getIncrTableList(self.spark, jsonPath, source, TableDict, replicaPath)
                log.info("::::Final Tables List are {}".format(tableList))
                res = obj.Start(tableList, job_name)
            else:
                log.info("::::Full Load Flag is enable")
                tableList = Jb.getTableList(self.spark, jsonPath, source, replicaPath)
                log.info("::::Final Tables List are {}".format(tableList))
                res = obj.Start(tableList, job_name)

            return res
        except Exception as e:
            log.error(str(e))
            return "Failed-" + str(e)

    jobName = "SegregationJob"
