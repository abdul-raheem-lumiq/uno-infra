from com.lumiq.framework.ingest.services.Dim_Sample_Service import Dim_Sample_Service
from com.lumiq.framework.utils.DFUtils import DFUtils as F
from com.lumiq.framework.utils.JobUtils import JobUtils as Jb
import logging as logs


class Dim_Sample_Job(object):
    def __init__(self, spark, glueContext, Config):
        self.spark = spark
        self.Config = Config
        self.glueContext = glueContext

    def execute(self, args):
        try:
            # Getting required value from parameter
            job_name = str(args['jobName']).strip(' ')
            job_id = args['JOB_RUN_ID']
            logs.info("::::Job {} has been started.".format(job_name))


            # Config Properties
            CuratedBucketPath = self.Config.get('Curated', 'curated.bucket.path')
            StatePath = self.Config.get('Envirnoment', 'S3.table.state.path')
            parentPath = self.Config.get('Curated', 'curated.prod.db')

            # Enabling Logs
            logs.basicConfig()
            logs.getLogger().setLevel(logs.INFO)

            # Service object
            obj = Dim_Sample_Service(self.spark, self.glueContext, self.Config)

            # Calling Service method
            (res, finalDF, stateDF) = obj.BusinessLogic(args)
            finalDF1 = finalDF.cache()
            finalCount = finalDF1.count()

            #For Audit
            args['FinalCount'] = str(finalCount)

            if finalCount > 0:
                logs.info("::::Final DataFrame Count is {}.".format(finalCount))

                # Curated Layer Path
                OutPath = F.s3Path(CuratedBucketPath + "/" + parentPath + '/DIM_SAMPLE/')
                logs.info("::::Writing Table DIM_SAMPLE_JOB to Curated Bucket at Path {}".format(OutPath))

                res1 = Jb.writeDF(finalDF1, OutPath)
                if res1.upper() == 'SUCCESS':
                    logs.info("::::Writing Data Table DIM_SAMPLE_JOB to Curated Bucket has been completed.")

                    logs.info("::::Writing Data to Consumption Layer. Mode is Upsert.")
                    res2 = Jb.updateOverAllDataRedShift(self.glueContext, self.Config, "schema_name", "dim_sample", finalDF1)
                    if res2.upper() == "SUCCESS":
                        logs.info("::::Writing Data to Consumption Layer has been completed.")

                        # Update Final State
                        logs.info("::::Writing Final State to State Path {}".format(StatePath))
                        # stateDF.show(truncate=False)
                        Jb.writeStateDF(stateDF, StatePath)
                    else:
                        logs.error("::::Writing Data to Consumption Layer has been failed.")
                        return res2
                else:
                    logs.error("::::Writing Data Table DIM_SAMPLE_JOB to Curated Bucket has been failed.")
                    return res1
            else:
                logs.warning("::::Final DataFrame Count is Zero.")
            return res
        except Exception as e:
            logs.error(e, exc_info=True)
            return ("Failed -" + str(e))

    # job name keyword
    jobName = "DimSampleJob"
