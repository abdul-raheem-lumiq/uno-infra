from com.lumiq.framework.utils.JobUtils import JobUtils as Jb
from com.lumiq.framework.utils.DFUtils import DFUtils as F
from pyspark.sql.functions import *
import logging as log
from pyspark.sql.types import StructType, StructField, StringType, LongType


class Compute_Service(object):
    def __init__(self, spark, glueContext, Config):
        self.spark = spark
        self.Config = Config
        self.glueContext = glueContext

    def Compute(self, args):
        spark = self.spark
        Config = self.Config
        glueContext = self.glueContext
        stripMargin = F.strip_margin

        # Enabling log
        log.basicConfig()
        log.getLogger().setLevel(log.INFO)

        # Get Parameters
        JobName = args['JobName']
        Source = args['Source']
        Key = args['KEY']
        Schema = "public"
        Table = str(args['SourceTable'])

        # Config Properties fetch
        ComputeJsonPath = Config.get('Environment', 'S3.compute.config.path')
        StatePath = self.Config.get('Environment', 'S3.table.state.path')
        TableJsonPath = Config.get('Environment', 'S3.table.master.path')
        StandardPath = Config.get('Standard', 'standard.bucket.path')
        RawPath = Config.get('Raw', 'raw.bucket.path')

        # EmptyDF
        schema = StructType([StructField('Col1', StringType(), True)])
        emptyDF = spark.createDataFrame([], schema).cache()

        Run_Time = F.TimeNow()
        log.info("::::The Job Run Time is {}".format(Run_Time))
        try:
            (JbCount, JBDF) = Jb.readStandardTableUsingGlue(glueContext, Config, Source, Schema, Table)
            args['JBCount'] = str(JbCount)
            args['StateCount'] = str(0)
            args['SourceTable'] = str(Schema) + str(".") + str(Table)
            args['SourceAWSService'] = "S3"
            if JbCount > 0:
                (FirstLoad, ColName, edl_state) = Jb.readLookUpTable(spark, StatePath, TableJsonPath, JobName,
                                                                     Source, Schema, Table)
                if FirstLoad:
                    df = JBDF
                    StCount = JbCount
                else:
                    df = JBDF.filter(col(ColName) > lit(edl_state))
                    StCount = df.count()

                log.info("{}::::Return First Load Flag from State Control Table is {}".format(Key, str(FirstLoad)))
                log.info(
                    "{}::::Incremental Count from Job Bookmark is {} and from State is {}".format(Key, str(JbCount),
                                                                                                  str(StCount)))

                args['StateCount'] = str(StCount)
                args['Watermark'] = str(edl_state)

                if StCount > 0:
                    stateDF = Jb.writeLookUpTable(spark, df, TableJsonPath, JobName, Source, Schema, Table, Run_Time)
                    df.createOrReplaceTempView(Table)

                    JsonDF = spark.read.option("multiLine", "true").json(ComputeJsonPath) \
                        .filter(upper(col("Key")) == lit(Key)) \
                        .withColumn("Order", col("Order").cast("Int"))
                    ViewSql = list(map(lambda r: r.asDict(),
                                       JsonDF.select(col("View"), col("Sql")).orderBy(col("Order")).collect()))
                    Jb.CreateView(spark, ViewSql)
                    df1 = spark.sql("SELECT * FROM FinalView")
                    FinalDF = df1.withColumn("JobName", lit(JobName)) \
                        .withColumn("JobRunTime", to_timestamp(lit(Run_Time)))

                    return ("Success", FinalDF, stateDF)

                else:
                    log.info("{}::::No Incremental Data found for Event {} after State Check. "
                             "The Last State Value is {} in Column {}."
                             .format(Key, Table, str(edl_state), ColName))
                    return ("SUCCESS", emptyDF, emptyDF)
            else:
                log.info("{}::::No Incremental Data found for Event {} after JobBookmark Check.".format(Key, Table))
                return ("SUCCESS", emptyDF, emptyDF)
        except Exception as e:
            log.error(e, exc_info=True)
            return ("Failed :-" + str(e), emptyDF)
