from com.lumiq.framework.utils.JobUtils import JobUtils as Jb
from com.lumiq.framework.utils.DFUtils import DFUtils as F
from com.lumiq.framework.utils.SecretUtils import SecretUtils as Sr
from pyspark.sql.functions import *
from awsglue.dynamicframe import DynamicFrame
import logging as log
from pyspark.sql.types import *


class Incremental_Ingestion_Service(object):
    def __init__(self, spark, glueContext, Config, jobName):
        self.spark = spark
        self.Config = Config
        self.glueContext = glueContext
        self.jobName = jobName

    def readSource(self, source_config_json, table_name, primary_keys, watermark_column):
        spark = self.spark
        Config = self.Config
        glueContext = self.glueContext
        jobName = self.jobName
        stripMargin = F.strip_margin

        # Enabling log
        log.basicConfig()
        log.getLogger().setLevel(log.INFO)

        schema = StructType([StructField('col1', StringType(), True)])
        emptyDF = spark.createDataFrame([], schema).cache()

        # secret_manager_id = source_config_json['secret_manager_id']
        source_engine = source_config_json['engine']

        if source_engine.upper() != "S3":
            source_type = source_config_json['engine']
            host = source_config_json['host']
            port = source_config_json['port']
            db_name = source_config_json['db_name']

            if 'secret_manager_id' in source_config_json:
                secret_manager_id = source_config_json['secret_manager_id']
                source_secret = Sr.getSecret(secret_manager_id)
                source_secret['engine'] = source_type
                source_secret['host'] = host
                source_secret['port'] = port
                source_secret['dbname'] = db_name
            else:
                username = source_config_json['username']
                password = source_config_json['password']
                source_secret = {
                    "engine": source_type,
                    "host": host,
                    "port": port,
                    "dbname": db_name,
                    "username": username,
                    "password": password
                }
        else:
            source_type = "S3"
        log.info(f" source_secret ::: {source_secret}")

        source_options = {k: v for k, v in source_config_json.items() if k not in ['secret_manager_id', 'host', 'port', 'db_name', 'schema']}

        try:

            if source_type.upper() == "MYSQL":

                log.info("::::Reading Data From MySQL Source")
                
                source_schema = source_config_json['source_schema']
                state_df, max_watermark_val, FullLoad = Jb.getPreviousStates(spark,Config,jobName,source_schema,table_name)

                if FullLoad == False:

                    log.info("::::Pre Reading Source - State")
                    # state_df.show()

                    query = """SELECT * FROM  {}.{} WHERE {} > '{}'""".format(source_schema,table_name,watermark_column,max_watermark_val)

                    source_df = Jb.readFromJDBCUsingQry(spark,query,source_secret,source_options)

                    return ("Success",state_df,source_df, FullLoad)
                
                else:

                    log.info("::::No State Found. Doing Full Load For the Source")

                    source_df = Jb.readFromJDBC(spark,source_schema,table_name,source_secret,source_options)

                    return ("Success",state_df,source_df, FullLoad)

            elif source_type.upper() == "ORACLE":

                log.info("::::Reading Data From Oracle Source")
                
                source_schema = source_config_json['source_schema']
                source_df = Jb.readFromJDBC(spark,source_schema,table_name,source_secret,source_options)
                return ("Success",source_df)

            elif source_type.upper() == "POSTGRES":
                log.info("::::Reading Data From Postgres Source")

                source_schema = source_config_json['source_schema']
                # state_df, max_watermark_val, FullLoad = Jb.getPreviousStates(spark, Config, jobName, source_schema, table_name, watermark_column)
                state_df, max_watermark_val, FullLoad = Jb.getPreviousStatesUsingAPI(spark, Config, jobName, source_schema, table_name, watermark_column)

                if not FullLoad:

                    log.info("::::Pre Reading Source - State")
                    # state_df.show(truncate=False)
                    # query = """SELECT * FROM  {}.{} {}""".format(source_schema, table_name, state_query)
                    query = """SELECT * FROM  {}.{} WHERE coalesce({}) > '{}'""".format(source_schema, table_name, watermark_column, max_watermark_val)
                    log.info(f"::::Query to run {query}")

                    source_df = Jb.readFromJDBCUsingQry(spark, query, source_secret, source_options)

                    return "Success", state_df, source_df, FullLoad

                else:

                    log.info("::::No State Found. Doing Full Load For the Source")

                    source_df = Jb.readFromJDBC(spark, source_schema, table_name, source_secret, source_options)

                    return "Success", state_df, source_df, FullLoad

            elif source_type.upper() == "MSSQL":

                log.info("::::Reading Data From MS-SQL Source")
                
                source_schema = source_config_json['source_schema']
                source_df = Jb.readFromJDBC(spark,source_schema,table_name,source_secret,source_options)
                return ("Success",source_df)

            elif source_type.upper() == "IBMDB2":
                
                log.info("::::Reading Data From IBM DB2 Source")
                
                source_schema = source_config_json['source_schema']
                source_df = Jb.readFromJDBC(spark,source_schema,table_name,source_secret,source_options)
                return ("Success",source_df)

            elif source_type.upper() == "S3":
                
                log.info("::::Reading Data From S3 Source")
                
                # source_df = Jb.readFromJDBC(self.spark,source_schema,table_name,source_secret)
                return ("Success",source_df)

            elif source_type.upper() == "REDSHIFT":

                log.info("::::Reading Data From Redshift Source")
                
                # source_df = Jb.readFromJDBC(self.spark,source_schema,table_name,source_secret)
                return ("Success",source_df)

            else:
                log.info("::::Source Invalid Or Not Supported")
                return ("Failed - Invalid Source", emptyDF)

                        
        except Exception as e:
            log.error(e, exc_info=True)
            return ("Failed -" + str(e), emptyDF)
    
    def writeToTarget(self, source_df, target_config_json,table_name,primary_keys,watermark_column,incremental_mode, FullLoad):
        spark = self.spark
        Config = self.Config
        glueContext = self.glueContext
        stripMargin = F.strip_margin

        # Enabling log
        log.basicConfig()
        log.getLogger().setLevel(log.INFO)

        schema = StructType([StructField('col1', StringType(), True)])
        emptyDF = spark.createDataFrame([], schema).cache()

        # target_endpoint = target_config_json['secret_manager_id']
        target_engine = target_config_json['engine']

        if target_engine.upper() != "S3":
            target_endpoint = target_config_json['secret_manager_id']
            target_secret = Sr.getSecret(target_endpoint)
            target_type = target_secret['engine']

        else:
            target_type = "S3"
            target_schema = target_config_json['destination_schema']
            target_s3_bucket = target_config_json['s3_bucket_name']
            target_s3_directory = target_config_json['s3_directory']

            # removing starting and trailing slashes if any
            target_s3_bucket = target_s3_bucket.lstrip('/').rstrip('/')
            target_s3_directory = target_s3_directory.lstrip('/').rstrip('/')

            target_path = f's3://{str(target_s3_bucket)}/{str(target_s3_directory)}/'

        target_options = {k:v for k,v in target_config_json.items() if k not in ['secret_manager_id', 'host', 'port', 'db_name', 'schema']}

        try:

            if target_type.upper() == "MYSQL":

                log.info("::::Writing Data To MySQL Target")
                
                target_schema = target_secret['dbname']
                res = Jb.writeUsingJDBC(spark,Config,source_df,None,target_schema,table_name,target_secret,"drop_write",target_options)
                return res

            elif target_type.upper() == "ORACLE":

                log.info("::::Writing Data To Oracle Target")
                
                target_schema = target_secret['dbname']
                res = Jb.writeUsingJDBC(spark,Config,source_df,None,target_schema,table_name,target_secret,"drop_write",target_options)
                return res

            elif target_type.upper() == "POSTGRES":

                log.info("::::Writing Data To Postgres Target")
                
                target_schema = target_secret['dbname']
                res = Jb.writeUsingJDBC(spark, Config, source_df, None, target_schema, table_name, target_secret, "drop_write", target_options)
                return res

            elif target_type.upper() == "MSSQL":

                log.info("::::Writing Data To MS-SQL Target")
                
                target_schema = target_secret['dbname']
                res = Jb.writeUsingJDBC(spark,Config,source_df,None,target_schema,table_name,target_secret,"drop_write",target_options)
                return res

            elif target_type.upper() == "IBMDB2":

                log.info("::::Writing Data To IBM DB2 Target")
                
                target_schema = target_secret['dbname']
                res = Jb.writeUsingJDBC(spark,Config,source_df,None,target_schema,table_name,target_secret,"drop_write",target_options)
                return res

            elif target_type.upper() == "S3":

                log.info("::::Writing Data To S3 Target")
                sync_type = 'append'
                if target_config_json['sync_type'].strip().upper() == 'INO':
                    sync_type = 'overwrite'
                log.info(f"::::Writing Data To S3 Target in {sync_type} mode")
                log.info(f"::::Writing Data To path : {target_path}")
                if 'partitionColumns' in target_config_json:
                    partition_keys = target_config_json['partitionColumns']
                else:
                    partition_keys = None

                db_name = target_config_json['db_name']
                res = Jb.writeDataIntoS3CatalogTable(spark, source_df, target_path, target_schema, table_name, partition_keys, sync_type, db_name)
                
                return res

            elif target_type.upper() == "REDSHIFT":

                log.info("::::Writing Data To Redshift")

                if FullLoad == True:
                
                    res = Jb.writeIntoRedshift(glueContext,source_df,table_name,target_secret,target_options,'overwrite',primary_keys)

                else:

                    res = Jb.writeIntoRedshift(glueContext,source_df,table_name,target_secret,target_options,incremental_mode,primary_keys)

                return res

            else:
                log.info("::::Target Invalid Or Not Supported")
                return ("Failed - Invalid Target", emptyDF)
                        
        except Exception as e:
            log.error(e, exc_info=True)
            return ("Failed -" + str(e))
