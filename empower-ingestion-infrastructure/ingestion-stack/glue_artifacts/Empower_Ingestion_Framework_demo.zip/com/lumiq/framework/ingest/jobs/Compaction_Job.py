from com.lumiq.framework.ingest.services.Compaction_Service import Compaction_Service
import logging as logs


class Compaction_Job(object):
    def __init__(self, spark, glueContext, Config):
        self.spark = spark
        self.Config = Config
        self.glueContext = glueContext

    def execute(self, args):
        try:
            GlueJobName = args['JOB_NAME']
            parameter = str(args['jobName']).strip(' ')
            validSource = self.Config.get('Envirnoment', 'source.list')
            srcList = list(map(lambda x: x.strip(' '), validSource.split(",")))
            job_name = parameter.split(",")[0].strip(' ')
            source = parameter.split(",")[1].strip(' ').upper()
            run = parameter.split(",")[2].strip(' ').upper()
            if source not in srcList:
                raise ValueError(
                    "::::Source with name {} not found in valid source list {}.".format(source, str(srcList)))

            # Enabling Logs
            logs.basicConfig()
            logs.getLogger().setLevel(logs.INFO)

            # creating ApiClientDetailsService object
            obj = Compaction_Service(self.spark, self.glueContext, self.Config)

            # Getting required value from parameter
            logs.info("::::Job {} has been started.".format(job_name))
            res = obj.Start(source, run)
            return res
        except Exception as e:
            logs.error(e, exc_info=True)
            return "Failed-" + str(e)

    # tranformation job name
    jobName = "CompactionJob"
