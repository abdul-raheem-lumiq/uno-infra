from com.lumiq.framework.utils.JobUtils import JobUtils as Jb
from com.lumiq.framework.utils.DFUtils import DFUtils as F
from pyspark.sql.functions import *
import logging as logs
from pyspark.sql.types import StructType, StructField, StringType


class Mapping_Service(object):
    def __init__(self, spark, glueContext, Config):
        self.spark = spark
        self.Config = Config
        self.glueContext = glueContext

    def Mapping(self, args):
        spark = self.spark
        Config = self.Config
        glueContext = self.glueContext

        # Enabling log
        logs.basicConfig()
        logs.getLogger().setLevel(logs.INFO)

        # GetParametes
        JobName = args['JobName']
        Source = args['Source']
        Key = args['KEY']
        Schema = "public"
        Table = str(args['SourceTable'])

        # Config Properties fetch
        StatePath = Config.get('Environment', 'S3.table.state.path')
        JsonPath = Config.get('Environment', 'S3.table.master.path')

        # EmptyDF
        dfschema = StructType([StructField('COL1', StringType(), True)])
        emptyDF = spark.createDataFrame([], dfschema).cache()

        # Current Timestamp
        Run_Time = F.TimeNow()
        logs.info("::::The Job Run Time is {}.".format(Run_Time))
        try:
            (JbCount, JBDF) = Jb.readStandardTableUsingGlue(glueContext, Config, Source, Schema, Table)

            # Auditing
            args['JBCount'] = str(JbCount)
            args['StateCount'] = str(0)
            args['SourceTable'] = str(Schema) + str(".") + str(Table)
            args['SourceAWSService'] = "S3"
            if JbCount > 0:
                (FirstLoad, ColName, edl_state) = Jb.readLookUpTable(spark, StatePath, JsonPath, JobName, Source,
                                                                     Schema, Table)
                if FirstLoad:
                    df = JBDF
                    StCount = JbCount
                else:
                    df = JBDF.filter(col(ColName) > lit(edl_state))
                    StCount = df.count()

                logs.info("{}::::Return First Load Flag from State Control Table is {}".format(Table, str(FirstLoad)))
                logs.info(
                    "{}::::Incremental Count from Job Bookmark is {} and from State is {}".format(Table, str(JbCount),
                                                                                                  str(StCount)))
                args['StateCount'] = str(StCount)
                args['Watermark'] = str(edl_state)
                if StCount > 0:
                    stateDF = Jb.writeLookUpTable(spark, df, JsonPath, JobName, Source, Schema, Table, Run_Time)
                    apiDF1 = Jb.getLatestData(spark, Config, df, Source, Schema, Table, False)
                    (res1, MapDF) = Jb.ExecuteFuntion(spark, Config, apiDF1, Key)
                    logs.info("{}::::Execute Function Status for Event {} is {} ".format(Key, Table, res1))
                    if res1.upper() == "SUCCESS":
                        FinalDF = MapDF.withColumn("JobName", lit(JobName)) \
                            .withColumn("JobRunTime", to_timestamp(lit(Run_Time)))

                    else:
                        FinalDF = emptyDF

                    if res1.upper() != "SUCCESS":
                        msg = "::::{} Mapping Job of the Table {} is failed while Mapping.".format(Key, Table)
                        logs.error(msg)
                        return ("Failed -" + msg, emptyDF, emptyDF)
                    else:
                        return ("SUCCESS", FinalDF, stateDF)
                else:
                    logs.info("{}::::No Incremental Data found after State Check. "
                             "The Last State Value is {} in Column {}."
                             .format(Key, Table, str(edl_state), ColName))
                    return ("SUCCESS", emptyDF, emptyDF)
            else:
                logs.info("{}::::No Incremental Data found for Event {} after JobBookmark Check.".format(Key, Table))
                return ("SUCCESS", emptyDF, emptyDF)

        except Exception as e:
            logs.error(e, exc_info=True)
            return ("Exception -" + str(e), emptyDF, emptyDF)
