from com.lumiq.framework.ingest.services.Incremental_Ingestion_Service import Incremental_Ingestion_Service
from com.lumiq.framework.utils.DFUtils import DFUtils as F
from com.lumiq.framework.utils.JobUtils import JobUtils as Jb
from pyspark.sql.types import *
from pyspark.sql.functions import *
import logging as logs
import json
from datetime import datetime

class Dim_Sample_Job(object):
    def __init__(self, spark, glueContext, Config):
        self.spark = spark
        self.Config = Config
        self.glueContext = glueContext

    def execute(self, args):
        job_start_time = datetime.today().strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        # Enabling Logs
        spark = self.spark
        glueContext = self.glueContext
        Config = self.Config
        logs.basicConfig()
        logs.getLogger().setLevel(logs.INFO)

        try:
            # Getting required value from parameter
            job_name = str(args['JOB_NAME']).strip(' ')
            job_id = args['JOB_RUN_ID']
            logs.info("::::Job {} has been started.".format(job_name))

            print("Recieved Arguments")
            print(args)

            json_param = json.loads(args['jsonparams'])

            print('Recieved these JSON Params')
            print(json_param)

            # table config
            source_table_name = json_param['source_table_name']
            destination_table_name = json_param['destination_table_name']

            # source config
            source_config_json = json_param['source'] # {"source":{"db_name":"postgres","host":"empower-poc-postgres.cepsv5f9ayrr.ap-south-1.rds.amazonaws.com","port":"5432","schema":["public"],"secret_manager_id":"postgres_secret","using_ssl":true}}
            source_schema = json_param['source_schema']
            source_config_json['source_schema'] = source_schema

            # destination config
            destination_config_json = json_param['destination'] # {"destination":{"s3_bucket_name":"empower-ingestion-rnd","s3_bucket_region":"ap-south-1","s3_directory":"/target_folder/","secret_manager_id":"S3"}}
            destination_config_json['destination_schema'] = json_param['destination_schema']
            sync_type = json_param['sync_type']
            destination_config_json['sync_type'] = sync_type
            if 'db_name' not in destination_config_json:
                destination_config_json['db_name'] = job_name + source_config_json['db_name']

            primary_keys = json_param['primary_key']
            watermark_columns = json_param['cursor_field']

            obj = Incremental_Ingestion_Service(spark, glueContext, Config, job_name)

            # Calling Service method

            (res, state_df, source_df, FullLoad) = obj.readSource(source_config_json, source_table_name, primary_keys, watermark_columns)

            source_df_count = source_df.count()

            if res.upper() == "SUCCESS" and source_df_count > 0:

                logs.info("::::Source Data Ingestion Completed")
                logs.info("::::Count for Data Ingested is {}".format(str(source_df_count)))

                # logs.info("state_df::::" + str(state_df.show()))
                updated_state_df, updated_watermark_col_val = Jb.getUpdatedStates(spark, source_df, job_name, watermark_columns, source_schema, source_table_name)
                # logs.info("updated_state_df::::" + str(updated_state_df.show()))
                write_res = obj.writeToTarget(source_df, destination_config_json, destination_table_name, primary_keys, watermark_columns, sync_type, FullLoad)

                if write_res.upper() == "SUCCESS":
                    # return "SUCCESS"
                    # state_res = Jb.writeJobStates(self.Config, updated_state_df)
                    state_res = Jb.setStatesUsingAPI(self.Config, job_start_time, job_name, source_schema, source_table_name, watermark_columns, updated_watermark_col_val)
                    return state_res
                else:
                    return write_res

            elif res.upper() == "SUCCESS" and source_df_count == 0:
                logs.info("::::No Data Found in the Table")
                return res
            
            else:
                return res

        except Exception as e:
            logs.error(e, exc_info=True)
            return ("Failed -" + str(e))

    # job name keyword
    jobName = "IncrementalIngestionJob"
